---
id: calendar-clock
name: 日历与时钟
description: 创建日程提醒、设置闹钟与倒计时：优先使用系统意图工具，界面操作兜底。
packages: [com.android.calendar, com.google.android.calendar, com.android.deskclock, com.google.android.deskclock, com.miui.clock]
app_names: [日历, 时钟, 闹钟, Calendar, Clock]
tags: [日历, 闹钟, 计时器, 提醒]
priority: 90
---

# 日历与时钟操控经验

1. **优先调用专用系统工具（最快最稳）**：
   - 设置闹钟、倒计时或创建日历日程前，**先调用 `phone.calendar_reminder`**（支持 `query_events`、`create_event`、`set_alarm`、`set_timer`），无需手工点开 App 翻界面。
2. **界面兜底流程**：
   - 仅当 `calendar_reminder` 返回系统不支持或需要编辑已有复杂日程时，才通过 `app_manage(launch)` 打开日历/时钟 App。
   - 时钟 App 底部常见「闹钟」「时钟」「计时器」「秒表」四个标签，新建通常在右下角 `+` 悬浮按钮。
3. **结果核验**：创建后再次调用 `calendar_reminder(action="query_events")` 或 `screen_observe` 确认时间、标题与开关状态已生效。
