---
id: android-settings
name: 系统设置
description: 常见 Android 系统设置页面结构、搜索入口与权限/网络/显示开关直达路径。
packages: [com.android.settings, com.miui.securitycenter, com.coloros.settings, com.oplus.settings]
app_names: [设置, 系统设置, Settings]
tags: [系统设置, 权限, 网络, 显示, 蓝牙]
priority: 95
---

# 系统设置操控经验

1. **优先系统 API**：切换音量、亮度、旋转、勿扰、Wi-Fi、蓝牙、定位前，优先尝试 `phone.system_setting`，仅在系统限制或需细项调节时再进入「设置」界面。
2. **顶部搜索最快**：进入系统设置首页后，优先点击顶部的「搜索设置」输入框，直接输入目标关键词（如 `无障碍`、`权限`、`电池`、`默认应用`、`热点`），比逐级翻找菜单更稳且省步数。
3. **分组与二级开关**：
   - 控件树里开关（`Switch`）常与标题在同一 `LinearLayout`/`RelativeLayout` 内；优先点击开关本身的 `ref` 或整行容器。
   - 若开关处于弹窗确认（如关闭定位或开启热点），紧接着调用 `phone.screen_wait_change` 检查确认弹窗并点击「确定/允许」。
4. **国产 ROM 常见差异**：部分机型权限/自启动位于「应用设置 → 应用管理 → 具体应用 → 权限管理」，若首页未找到可直接搜索应用名。
