---
id: jd
name: 京东
description: 京东商品搜索、京东自营/规格筛选（如 16+512G）、多机型比价与参数核对经验。
packages: [com.jingdong.app.mall]
app_names: [京东, 京东商城, JD]
tags: [电商, 购物, 比价, 筛选, 京东]
priority: 92
---

# 京东操控经验

1. **顶部搜索连贯执行（`ui_batch`）**：
   - 在京东首页点击顶部搜索框后进入搜索输入页，可用 `phone.ui_batch` 一次完成：`[input(action="set_text", text="OPPO Find X9 16+512"), click(text="搜索")]` 并带 `observe_after: true`。
2. **规格筛选与防漏点（`ui_batch` + `expect_selected`）**：
   - 搜索结果页点击右上角「筛选」或快捷规格标签（如 `京东物流`、`自营`、`16GB+512GB`）后，若在弹窗内连续点筛选条件和底部「确定」，必须在点击筛选条件的步骤传 `expect_selected: true`（或 `prefer_gesture: true`），并在最后一步点「确定」（带 `wait_for_text: "确定"`），防止条件未选中就误点确定。
3. **多机型比价流程**：
   - 记录当前结果页前 3~5 个自营/官方旗舰店商品标题与价格后，直接点击顶部搜索栏修改关键词搜索下一款机型；全部收集完毕后主动调用 `phone.task_control(action="complete", step_summary="已完成京东比价数据收集")` 切回 CodeForge 输出对比表格。
4. **安全红线**：涉及「去结算」「提交订单」「立即支付」时必须停下交由用户确认。
