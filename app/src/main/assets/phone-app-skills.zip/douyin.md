---
id: douyin
name: 抖音
description: 抖音顶部搜索、上下滑切换视频、评论区打开与关注/收藏交互路径。
packages: [com.ss.android.ugc.aweme, com.ss.android.ugc.aweme.lite]
app_names: [抖音, 抖音极速版]
tags: [短视频, 搜索, 滑动]
priority: 80
---

# 抖音操控经验

1. **信息流特点**：主界面为全屏视频流，上下滑动切换视频（`ui_gesture(action="swipe", direction="up")` 为下一条），右侧纵向分布头像、点赞、评论、收藏、分享图标。
2. **精准查找**：避免在推荐流盲目滑动，优先点击右上角「搜索」放大镜图标，输入作者或关键词后切换到「视频」或「用户」Tab。
3. **屏幕分析辅助**：部分全屏视频叠层图标缺少可读文本，建议在定位右侧按钮或底部文案前使用 `phone.screen_observe` 结合 `phone.screenshot(analyze=true)` 确认坐标。
