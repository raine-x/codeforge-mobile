---
id: wechat
name: 微信
description: 微信底部四大 Tab、顶部搜索联系人/聊天、消息输入框粘贴与发送确认规范。
packages: [com.tencent.mm]
app_names: [微信, WeChat]
tags: [社交, 聊天, 搜索, 发送消息]
priority: 95
---

# 微信操控经验

1. **首页四大 Tab**：底部固定「微信」「通讯录」「发现」「我」。需要切换功能区时直接点击底部文字标签的 `ref`。
2. **快速找人 / 找群**：
   - 优先点击右上角「搜索」图标（放大镜）或进入「通讯录」后点顶部搜索框。
   - 输入联系人昵称/备注后，通常在「联系人」或「群聊」分组第一行出现，等待 `screen_wait_change` 后点击对应条目进入会话。
3. **消息输入与发送（重要）**：
   - 聊天页面底部输入框常为自定义 EditText，若 `ui_input(action="set_text")` 未生效，改用 `ui_input(action="paste", text=...)`（先写入剪贴板并粘贴）。
   - 发送消息属于对外通讯高风险动作，若启用了确认门控，系统会自动弹窗请求用户确认。
4. **弹窗与返回**：朋友圈、公众号文章或小程序内若需退回主界面，连续 `ui_global_action(action="back")` 后再 `screen_observe` 核对当前 Tab。
