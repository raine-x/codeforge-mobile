---
id: browser
name: 手机浏览器
description: Chrome / 系统浏览器地址栏输入网址、标签页切换、网页内查找与页面截图分析经验。
packages: [com.android.chrome, com.sec.android.app.sbrowser, com.UCMobile, com.tencent.mtt, com.heytap.browser, com.android.browser]
app_names: [Chrome, 浏览器, Browser, 夸克, QQ浏览器]
tags: [浏览器, 网页, URL, 搜索]
priority: 85
---

# 手机浏览器操控经验

1. **地址栏输入 URL**：点击顶部（或底部）地址栏 `url_bar` / `search_box`，使用 `ui_input(action="set_text", text="https://...")` 或粘贴，再执行 `ui_input(action="submit")`。
2. **WebView 控件树补充**：网页内部复杂 DOM（如 Canvas、图表、自定义按钮）在无障碍控件树中可能折叠为单个 `WebView` 节点；遇到点击不到具体按钮时，立即调用 `phone.screenshot(analyze=true)` 或 `phone.screen_analyze` 获取坐标。
3. **提示**：若用户只是要查公开资料而非操控手机端浏览器登录态，优先使用内置网络搜索或内置浏览器工具，无需切到外部浏览器 App。
