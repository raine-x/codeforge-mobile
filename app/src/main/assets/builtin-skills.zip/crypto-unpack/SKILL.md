---
name: crypto-unpack
display_name: 固件解包与流密码常量分析
description: 二进制熵分布、密码学魔数、自定义 Base64、已知明文 Keystream 推导与多变体 RC4 快速验证工作流
triggers: reverse_analysis,逆向,crypto,unpack,aes,tea,rc4,base64,entropy,加密,脱壳,密钥
enabled: true
---

# 固件解包与流密码常量分析

> 用于在授权样本中定位加密区段、推导流密码密钥流并快速验证候选密钥。

## 1. 密码学常量、自定义 Base64 字母表与高熵区扫描
```bash
python3 .codeforge/skills/crypto-unpack/references/crypto_constant_scan.py sample.bin
python3 .codeforge/skills/crypto-unpack/references/crypto_constant_scan.py libjiagu_a64.so --window 4096
```

## 2. 已知明文前缀（Known-Plaintext Oracle）与循环 XOR 自动推导
当多个加密资源共享相同头部（如 APICloud JS 固定以 `define(function(require, exports, module) {` 开头，或加密 DEX 以 `dex\n035\x00` 开头）时，一行命令反推 Keystream 并测试循环 XOR 周期：
```bash
# 对加密 JS 用已知明文前缀反推 keystream
python3 .codeforge/skills/crypto-unpack/references/crypto_constant_scan.py main.js --known-prefix "define(function(require, exports, module) {"

# 对偏移 0x4770 处的加密 DEX 载荷用 DEX 魔数反推 8 字节/16 字节循环 XOR 密钥
python3 .codeforge/skills/crypto-unpack/references/crypto_constant_scan.py classes.dex --offset 0x4770 --known-prefix "hex:6465780a30333500"
```

## 3. 多变体 RC4（标准 / Drop256 / 交错扩展密钥）与自定义 Base64 一键验证
无需每次手写 KSA/PRGA，一次性测试标准 RC4、360 常用 RC4-drop256 以及 APICloud 常用交错密钥扩展 RC4（`K[2i]=key[i], K[2i+1]=key[i+1]`）：
```bash
# 同时测试多个候选密钥（支持明文字符串或 hex:...）在三种 RC4 变体下的解密结果
python3 .codeforge/skills/crypto-unpack/references/crypto_constant_scan.py main.js --rc4-key "c70e3388" --rc4-key "hex:c70e3388" --rc4-key "{DATA_4}"

# 使用自定义或标准 64 字符表解码 Base64 字符串
python3 .codeforge/skills/crypto-unpack/references/crypto_constant_scan.py main.js --b64-decode "w5fDqMOQw6Q0anNCwo7D"
```
