---
name: crypto-unpack
display_name: 固件解包与密码学常量识别
description: 二进制熵分布扫描与密码学魔数定位：识别 AES S-Box、TEA/XTEA/XXTEA delta、SHA/MD5/CRC32/ChaCha20 常量与可疑加密区段
triggers: crypto,unpack,aes,tea,rc4,entropy,加密,常量,固件
enabled: true
---

# 固件解包与密码学常量识别

> 只读取证工作流：用于在授权样本或固件里定位压缩区段、密钥表与常见密码算法实现，不篡改原样本。

## 1. 一键信息熵与常量扫描
对目标二进制运行内置纯 Python 扫描器（无需第三方依赖）：
```bash
python3 .codeforge/skills/crypto-unpack/references/crypto_constant_scan.py sample.bin
python3 .codeforge/skills/crypto-unpack/references/crypto_constant_scan.py libnative.so --window 4096
```

## 2. 常见算法特征对照表
- **AES / Rijndael**：正向 S-Box 开头 `63 7c 77 7b f2 6b 6f c5`；逆向 S-Box 开头 `52 09 6a d5 30 36 a5 38`。
- **TEA / XTEA / XXTEA**：幻数 `0x9E3779B9`（小端 `b9 79 37 9e`）或 `0x61C88647`（`47 86 c8 61`）。
- **ChaCha20 / Salsa20**：常量串 `"expand 32-byte k"` / `"expand 16-byte k"`。
- **MD5 / SHA-1 / SHA-256 / SM3**：初始 IV 与轮常量表（如 `0x67452301`、`0x6a09e667`、`0x7380166f`、`0x428a2f98`）。
- **CRC32 / Zlib / Gzip / LZ4 / XZ**：多项式表 `0xEDB88320`、`1f 8b 08`、`78 9c`、`04 22 4d 18`、`fd 37 7a 58 5a 00`。
- **魔改 Base64**：查找长度恰好 64 字节且不含重复字符的可打印字母表偏移。

## 3. 信息熵判据
- 熵值 `< 3.5`：常见于稀疏表/ASCII/配置；
- 熵值 `5.0 ~ 6.8`：正常机器码或未压缩结构；
- 熵值 `> 7.5`（满值 `8.0`）：强加密区段、压缩载体或加固壳载荷，可按偏移截取后对比头魔数与异或规律。
