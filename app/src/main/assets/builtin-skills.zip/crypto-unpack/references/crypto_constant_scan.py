#!/usr/bin/env python3
"""Pure-stdlib Cryptographic Constant, Custom Base64, Stream-Cipher Oracle & Entropy Scanner.

Features:
1. Scans binaries for AES S-Box, TEA/XTEA/XXTEA, ChaCha20/Salsa20, SHA-256/MD5/SM3, CRC32, Zlib/Gzip/LZ4/XZ
2. Detects candidate 64-byte custom Base64 alphabet tables and decodes custom-alphabet strings (--b64-decode)
3. Locates high-entropy encrypted/compressed regions (--window)
4. Known-plaintext keystream & repeating-XOR analyzer (--known-prefix)
5. Multi-variant RC4 tester (--rc4-key): tests standard RC4, RC4-drop256, and interleaved-key RC4 in one pass
"""

from __future__ import annotations

import argparse
import math
import re
import sys
from collections import Counter
from pathlib import Path

SIGNATURES: list[tuple[str, bytes]] = [
    ("AES Forward S-Box", bytes.fromhex("637c777bf26b6fc53001672bfed7ab76")),
    ("AES Inverse S-Box", bytes.fromhex("52096ad53036a538bf40a39e81f3d7fb")),
    ("TEA/XTEA/XXTEA delta (LE 0x9E3779B9)", bytes.fromhex("b979379e")),
    ("TEA/XTEA/XXTEA -delta (LE 0x61C88647)", bytes.fromhex("4786c861")),
    ("ChaCha20/Salsa20 constant (32-byte)", b"expand 32-byte k"),
    ("ChaCha20/Salsa20 constant (16-byte)", b"expand 16-byte k"),
    ("SHA-256 K[0..3] (LE)", bytes.fromhex("982f8a4291443771cffbc0b5a5db8be9")),
    ("SHA-256 K[0..3] (BE)", bytes.fromhex("428a2f9871374491b5c0fbcfe9b5dba5")),
    ("MD5/SHA-1 H0 (LE 0x67452301)", bytes.fromhex("0123456789abcdef")),
    ("SM3 IV[0] (BE 0x7380166F)", bytes.fromhex("7380166f")),
    ("CRC32 IEEE poly (LE 0xEDB88320)", bytes.fromhex("2083b8ed")),
    ("Zlib default stream (78 9c)", bytes.fromhex("789c")),
    ("Gzip magic (1f 8b 08)", bytes.fromhex("1f8b08")),
    ("LZ4 frame magic (04 22 4d 18)", bytes.fromhex("04224d18")),
    ("XZ stream magic (fd 37 7a 58 5a 00)", bytes.fromhex("fd377a585a00")),
]


def shannon_entropy(chunk: bytes) -> float:
    if not chunk:
        return 0.0
    n = len(chunk)
    counts = Counter(chunk)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())


def find_all(data: bytes, needle: bytes) -> list[int]:
    out = []
    start = 0
    while True:
        idx = data.find(needle, start)
        if idx < 0:
            break
        out.append(idx)
        start = idx + 1
        if len(out) >= 16:
            break
    return out


def rc4_crypt(data: bytes, key: bytes, drop: int = 0) -> bytes:
    if not key:
        return data
    s = list(range(256))
    j = 0
    klen = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % klen]) & 0xFF
        s[i], s[j] = s[j], s[i]
    i = 0
    j = 0
    for _ in range(drop):
        i = (i + 1) & 0xFF
        j = (j + s[i]) & 0xFF
        s[i], s[j] = s[j], s[i]
    out = bytearray(len(data))
    for idx, b in enumerate(data):
        i = (i + 1) & 0xFF
        j = (j + s[i]) & 0xFF
        s[i], s[j] = s[j], s[i]
        k = s[(s[i] + s[j]) & 0xFF]
        out[idx] = b ^ k
    return bytes(out)


def rc4_interleaved_key(key: bytes) -> bytes:
    if len(key) < 2:
        return key
    expanded = bytearray(len(key) * 2)
    for idx in range(len(key)):
        expanded[2 * idx] = key[idx]
        expanded[2 * idx + 1] = key[(idx + 1) % len(key)]
    return bytes(expanded)


def custom_b64_decode(encoded: str, alphabet: str) -> bytes:
    if len(alphabet) != 64:
        raise ValueError(f"Custom Base64 alphabet must be 64 chars (got {len(alphabet)})")
    rev = {ch: i for i, ch in enumerate(alphabet)}
    out = bytearray()
    buf = 0
    bits = 0
    for ch in encoded.strip():
        if ch == "=" or ch not in rev:
            continue
        buf = (buf << 6) | rev[ch]
        bits += 6
        if bits >= 8:
            bits -= 8
            out.append((buf >> bits) & 0xFF)
    return bytes(out)


def parse_bytes_spec(spec: str) -> bytes:
    if spec.startswith("hex:"):
        return bytes.fromhex(spec[4:].replace(" ", ""))
    return spec.encode("utf-8")


def main() -> int:
    ap = argparse.ArgumentParser(description="Scan binary for crypto constants, custom Base64, keystreams, and RC4 variants.")
    ap.add_argument("file", type=Path, help="Target binary file")
    ap.add_argument("--window", type=int, default=4096, help="Entropy sliding chunk size (default: 4096)")
    ap.add_argument("--offset", default="0", help="Start offset for --known-prefix / --rc4-key (e.g. 0x4770)")
    ap.add_argument("--known-prefix", default="", help="Known plaintext prefix (e.g. 'dex\\n035\\x00' or 'hex:6465780a' or 'define(function')")
    ap.add_argument("--rc4-key", action="append", default=[], help="Test candidate RC4 key (supports plain string or 'hex:...')")
    ap.add_argument("--b64-alphabet", default="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", help="64-char Base64 alphabet")
    ap.add_argument("--b64-decode", default="", help="Decode string using --b64-alphabet")
    args = ap.parse_args()

    if args.b64_decode:
        dec = custom_b64_decode(args.b64_decode, args.b64_alphabet)
        print(f"[Base64 Decoded ({len(dec)}B)] hex={dec.hex()} ascii={dec.decode('utf-8', errors='replace')!r}")

    data = args.file.read_bytes()
    start_off = int(args.offset, 0)
    sub_data = data[start_off:]
    print(f"File={args.file} size={len(data)} bytes overall_entropy={shannon_entropy(data):.3f}")
    print(
        "[Toolkit] Flags: --known-prefix <str_or_hex:...> (keystream & repeating-XOR oracle), "
        "--rc4-key <key> (tests standard/drop256/interleaved RC4), --b64-decode <str>."
    )

    if args.known_prefix:
        pt = parse_bytes_spec(args.known_prefix)
        ct = sub_data[: len(pt)]
        ks = bytes(c ^ p for c, p in zip(ct, pt))
        print(f"\n[Known-Plaintext Keystream Oracle @ off=0x{start_off:x} (len={len(ks)}B)]")
        print(f"  Ciphertext prefix : {ct.hex()}")
        print(f"  Plaintext prefix  : {pt.hex()} ({pt.decode('utf-8', errors='replace')!r})")
        print(f"  Derived keystream : {ks.hex()}")
        # Test if repeating XOR with period 1..16 decrypts printable or DEX structure
        for period in (1, 2, 4, 8, 16):
            if len(ks) >= period:
                k_rep = ks[:period]
                sample_dec = bytes(sub_data[i] ^ k_rep[i % period] for i in range(min(96, len(sub_data))))
                printable_ratio = sum(1 for b in sample_dec if 32 <= b < 127 or b in (9, 10, 13)) / max(1, len(sample_dec))
                print(
                    f"  [Repeating-XOR period={period:2d} key={k_rep.hex()}] "
                    f"printable={printable_ratio:.0%} preview={sample_dec[:48].decode('utf-8', errors='replace')!r}"
                )

    if args.rc4_key:
        print(f"\n[RC4 Multi-Variant Key Tests @ off=0x{start_off:x}]")
        sample = sub_data[:128]
        for k_spec in args.rc4_key:
            k_bytes = parse_bytes_spec(k_spec)
            variants = [
                ("RC4-standard", rc4_crypt(sample, k_bytes, drop=0)),
                ("RC4-drop256", rc4_crypt(sample, k_bytes, drop=256)),
                ("RC4-interleaved", rc4_crypt(sample, rc4_interleaved_key(k_bytes), drop=0)),
            ]
            for vname, dec in variants:
                pr = sum(1 for b in dec if 32 <= b < 127 or b in (9, 10, 13)) / max(1, len(dec))
                print(
                    f"  key={k_spec!r} ({k_bytes.hex()}) [{vname:<15}] "
                    f"printable={pr:.0%} hex={dec[:24].hex()} ascii={dec[:56].decode('utf-8', errors='replace')!r}"
                )

    print("\n[Crypto / Compression Signatures]")
    found_any = False
    for label, pat in SIGNATURES:
        hits = find_all(data, pat)
        if hits:
            found_any = True
            offs = ", ".join(f"0x{h:x}" for h in hits)
            print(f"  {label}: {offs}")
    if not found_any:
        print("  (no known constant matched)")

    # Candidate 64-char unique ASCII tables (potential custom Base64 alphabets)
    b64_pat = re.compile(rb"[A-Za-z0-9+/=_\-\.!@#\$%\^&\*]{64}")
    b64_hits = []
    for m in b64_pat.finditer(data):
        s = m.group(0)
        if len(set(s)) == 64:
            b64_hits.append((m.start(), s.decode("ascii", errors="replace")))
        if len(b64_hits) >= 8:
            break
    if b64_hits:
        print("\n[Candidate 64-byte Alphabet Tables]")
        for off, tbl in b64_hits:
            print(f"  0x{off:x}: {tbl}")

    # High-entropy windows (>7.5)
    win = max(512, args.window)
    high = []
    for off in range(0, len(data), win):
        chunk = data[off : off + win]
        if len(chunk) < 256:
            continue
        ent = shannon_entropy(chunk)
        if ent >= 7.5:
            high.append((off, len(chunk), ent))
    if high:
        print(f"\n[High-Entropy Regions (>=7.5 bits/byte, window={win}, count={len(high)})]")
        for off, sz, ent in high[:20]:
            print(f"  off=0x{off:x}..0x{off+sz:x} ({sz}B) entropy={ent:.3f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
