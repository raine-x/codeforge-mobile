#!/usr/bin/env python3
"""Pure-stdlib cryptographic constant, custom Base64 alphabet, and Shannon entropy scanner."""

from __future__ import annotations

import argparse
import math
import re
import sys
from collections import Counter
from pathlib import Path

SIGNATURES: list[tuple[str, bytes]] = [
    ("AES Forward S-Box", bytes.fromhex("637c777bf26b6fc53001672bfed7ab76")),
    ("AES Inverse S-Box", bytes.fromhex("52096ad53036a538bf40a39e81f3d7fb")),
    ("TEA/XTEA/XXTEA delta (LE 0x9E3779B9)", bytes.fromhex("b979379e")),
    ("TEA/XTEA/XXTEA -delta (LE 0x61C88647)", bytes.fromhex("4786c861")),
    ("ChaCha20/Salsa20 constant (32-byte)", b"expand 32-byte k"),
    ("ChaCha20/Salsa20 constant (16-byte)", b"expand 16-byte k"),
    ("SHA-256 K[0..3] (LE)", bytes.fromhex("982f8a4291443771cf fb c0 b5 a5 db 8b e9".replace(" ", ""))),
    ("SHA-256 K[0..3] (BE)", bytes.fromhex("428a2f9871374491b5c0fbcfe9b5dba5")),
    ("MD5/SHA-1 H0 (LE 0x67452301)", bytes.fromhex("0123456789abcdef")),
    ("SM3 IV[0] (BE 0x7380166F)", bytes.fromhex("7380166f")),
    ("CRC32 IEEE poly (LE 0xEDB88320)", bytes.fromhex("2083b8ed")),
    ("Zlib default stream (78 9c)", bytes.fromhex("789c")),
    ("Gzip magic (1f 8b 08)", bytes.fromhex("1f8b08")),
]


def shannon_entropy(chunk: bytes) -> float:
    if not chunk:
        return 0.0
    n = len(chunk)
    counts = Counter(chunk)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())


def find_all(data: bytes, needle: bytes) -> list[int]:
    out = []
    start = 0
    while True:
        idx = data.find(needle, start)
        if idx < 0:
            break
        out.append(idx)
        start = idx + 1
        if len(out) >= 16:
            break
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description="Scan binary for crypto constants and high-entropy chunks.")
    ap.add_argument("file", type=Path, help="Target binary file")
    ap.add_argument("--window", type=int, default=4096, help="Entropy sliding chunk size (default: 4096)")
    args = ap.parse_args()

    data = args.file.read_bytes()
    print(f"File={args.file} size={len(data)} bytes overall_entropy={shannon_entropy(data):.3f}")

    print("\n[Crypto / Compression Signatures]")
    found_any = False
    for label, pat in SIGNATURES:
        hits = find_all(data, pat)
        if hits:
            found_any = True
            offs = ", ".join(f"0x{h:x}" for h in hits)
            print(f"  {label}: {offs}")
    if not found_any:
        print("  (no known constant matched)")

    # Candidate 64-char unique ASCII tables (potential custom Base64 alphabets)
    b64_pat = re.compile(rb"[A-Za-z0-9+/=_\-\.!@#\$%\^&\*]{64}")
    b64_hits = []
    for m in b64_pat.finditer(data):
        s = m.group(0)
        if len(set(s)) == 64:
            b64_hits.append((m.start(), s.decode("ascii", errors="replace")))
        if len(b64_hits) >= 8:
            break
    if b64_hits:
        print("\n[Candidate 64-byte Alphabet Tables]")
        for off, tbl in b64_hits:
            print(f"  0x{off:x}: {tbl}")

    # High-entropy windows (>7.5)
    win = max(512, args.window)
    high = []
    for off in range(0, len(data), win):
        chunk = data[off : off + win]
        if len(chunk) < 256:
            continue
        ent = shannon_entropy(chunk)
        if ent >= 7.5:
            high.append((off, len(chunk), ent))
    if high:
        print(f"\n[High-Entropy Regions (>=7.5 bits/byte, window={win}, count={len(high)})]")
        for off, sz, ent in high[:20]:
            print(f"  off=0x{off:x}..0x{off+sz:x} ({sz}B) entropy={ent:.3f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
