#!/usr/bin/env python3
"""Ready-to-Run Unicorn ARM64 ELF (.so) & JNI Function Emulation Harness.

Eliminates the 6 classic pitfalls when emulating Android ARM64 native libraries:
1. Maps all ELF PT_LOAD segments with page alignment and zero-filled .bss (p_memsz > p_filesz)
2. Applies .rela.dyn (R_AARCH64_RELATIVE) and hooks .rela.plt / GOT imports to working Python stubs
   (strlen, strcmp, strncmp, strcpy, strncpy, strcat, strdup, memcpy, memmove, memset, memcmp,
   malloc, calloc, realloc, free, sprintf, snprintf, __stack_chk_fail, __android_log_print, etc.)
3. Enables ARM64 FP/NEON/SIMD instructions (writes CPACR_EL1.FPEN = 0b11) so SIMD loops never trap
4. Sets up Stack (SP), Heap bump allocator, TLS (TPIDR_EL0) with valid stack canary, and sentinel LR
5. Provides a Fake JNIEnv* vtable (232 entries) with working jstring / jbyteArray / jobject helpers
   (GetStringUTFChars, NewStringUTF, GetArrayLength, GetByteArrayElements, NewByteArray, etc.)
6. Supports running pre-init functions (--init-call 0x1178), calling C or JNI functions (--call / --jni-call),
   and dumping arbitrary virtual memory or return buffers (--dump 0xc238:64, --dump ret:jstring).
"""

from __future__ import annotations

import argparse
import struct
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import elf_jni_scanner  # noqa: E402

PAGE_SIZE = 0x1000


def align_down(v: int, a: int = PAGE_SIZE) -> int:
    return v & ~(a - 1)


def align_up(v: int, a: int = PAGE_SIZE) -> int:
    return (v + a - 1) & ~(a - 1)


class Arm64JniHarness:
    STACK_BASE = 0x70000000
    STACK_SIZE = 0x00200000
    TLS_BASE = 0x71000000
    HEAP_BASE = 0x72000000
    HEAP_SIZE = 0x02000000
    STUB_BASE = 0x75000000
    STUB_SIZE = 0x00100000
    STOP_ADDR = 0x750FFF00

    def __init__(self, elf_path: Path, trace_calls: bool = False) -> None:
        try:
            import unicorn as uc  # type: ignore
            from unicorn import arm64_const as uc_a64  # type: ignore
        except ImportError as e:
            raise RuntimeError(
                "Unicorn not installed in environment. Install '逆向工具' in Settings -> Environment Packages."
            ) from e

        self.uc = uc
        self.a64 = uc_a64
        self.trace_calls = trace_calls
        self.elf = elf_jni_scanner.ElfImage(elf_path.read_bytes())
        if not self.elf.is_64 or self.elf.e_machine != 183:
            raise ValueError("Arm64JniHarness requires a 64-bit ARM64 (EM_AARCH64) ELF")

        self.mu = uc.Uc(uc.UC_ARCH_ARM64, uc.UC_MODE_ARM)
        self.heap_ptr = self.HEAP_BASE
        self.stub_addr_to_name: dict[int, str] = {}
        self.jni_slot_to_name: dict[int, str] = {}
        self.handles: dict[int, dict] = {}

        self._enable_fp_simd()
        self._map_elf_segments()
        self._setup_stack_tls_heap()
        self._setup_libc_and_jni_stubs()

    def _enable_fp_simd(self) -> None:
        # Enable CPACR_EL1 FPEN bits [21:20] = 0b11 so NEON/SIMD instructions do not raise UC_ERR_EXCEPTION
        try:
            cpacr = self.mu.reg_read(self.a64.UC_ARM64_REG_CPACR_EL1)
            self.mu.reg_write(self.a64.UC_ARM64_REG_CPACR_EL1, cpacr | (0x3 << 20))
        except Exception:
            pass

    def _map_elf_segments(self) -> None:
        mapped_pages: set[int] = set()
        for seg in self.elf.segments:
            if seg["type"] != elf_jni_scanner.PT_LOAD or seg["memsz"] == 0:
                continue
            start_page = align_down(seg["vaddr"])
            end_page = align_up(seg["vaddr"] + seg["memsz"])
            for pg in range(start_page, end_page, PAGE_SIZE):
                if pg not in mapped_pages:
                    self.mu.mem_map(pg, PAGE_SIZE, self.uc.UC_PROT_ALL)
                    mapped_pages.add(pg)
            off = seg["offset"]
            fsz = seg["filesz"]
            # Write relocated bytes from ElfImage (already has R_AARCH64_RELATIVE applied)
            chunk = bytes(self.elf.relocated[off : off + fsz])
            self.mu.mem_write(seg["vaddr"], chunk)

    def _setup_stack_tls_heap(self) -> None:
        self.mu.mem_map(self.STACK_BASE, self.STACK_SIZE, self.uc.UC_PROT_READ | self.uc.UC_PROT_WRITE)
        self.mu.mem_map(self.TLS_BASE, PAGE_SIZE * 4, self.uc.UC_PROT_READ | self.uc.UC_PROT_WRITE)
        self.mu.mem_map(self.HEAP_BASE, self.HEAP_SIZE, self.uc.UC_PROT_READ | self.uc.UC_PROT_WRITE)
        self.mu.mem_map(self.STUB_BASE, self.STUB_SIZE, self.uc.UC_PROT_ALL)

        self.mu.reg_write(self.a64.UC_ARM64_REG_SP, self.STACK_BASE + self.STACK_SIZE - 0x1000)
        # Set TPIDR_EL0 and write a deterministic stack canary at [TPIDR_EL0 + 0x28]
        try:
            self.mu.reg_write(self.a64.UC_ARM64_REG_TPIDR_EL0, self.TLS_BASE)
        except Exception:
            pass
        self.mu.mem_write(self.TLS_BASE + 0x28, struct.pack("<Q", 0xCAFEBABE12345678))
        # Write `ret` (d65f03c0) at STOP_ADDR
        self.mu.mem_write(self.STOP_ADDR, struct.pack("<I", 0xD65F03C0))

    def malloc(self, size: int) -> int:
        sz = max(16, align_up(size, 16))
        ptr = self.heap_ptr
        self.heap_ptr += sz
        return ptr

    def read_cstr(self, addr: int, max_len: int = 4096) -> bytes:
        if addr == 0:
            return b""
        buf = bytearray()
        cur = addr
        while len(buf) < max_len:
            b = bytes(self.mu.mem_read(cur, 1))
            if b == b"\x00":
                break
            buf.extend(b)
            cur += 1
        return bytes(buf)

    def alloc_cstr(self, data: bytes | str) -> int:
        raw = data.encode("utf-8") if isinstance(data, str) else data
        ptr = self.malloc(len(raw) + 1)
        self.mu.mem_write(ptr, raw + b"\x00")
        return ptr

    def alloc_jstring(self, s: str | bytes) -> int:
        raw = s.encode("utf-8") if isinstance(s, str) else s
        c_ptr = self.alloc_cstr(raw)
        handle = self.malloc(32)
        self.handles[handle] = {"kind": "jstring", "bytes": raw, "c_ptr": c_ptr}
        return handle

    def alloc_jbytearray(self, b: bytes) -> int:
        c_ptr = self.malloc(max(1, len(b)))
        if b:
            self.mu.mem_write(c_ptr, b)
        handle = self.malloc(32)
        self.handles[handle] = {"kind": "jbyteArray", "bytes": bytearray(b), "c_ptr": c_ptr, "len": len(b)}
        return handle

    def _setup_libc_and_jni_stubs(self) -> None:
        # 1. Populate GOT slots for imported libc/Android functions with stub addresses that execute `ret`
        stub_cursor = self.STUB_BASE
        for got_va, sym_name in self.elf.got_symbols.items():
            stub_va = stub_cursor
            stub_cursor += 8
            self.mu.mem_write(stub_va, struct.pack("<I", 0xD65F03C0))  # ret
            self.mu.mem_write(got_va, struct.pack("<Q", stub_va))
            self.stub_addr_to_name[stub_va] = sym_name

        # 2. Build Fake JNIEnv* & JNINativeInterface vtable (240 function slots)
        jni_stub_base = self.STUB_BASE + 0x10000
        vtable_addr = self.malloc(240 * 8)
        self.jni_env_ptr = self.malloc(8)
        self.mu.mem_write(self.jni_env_ptr, struct.pack("<Q", vtable_addr))
        self.thiz_obj = self.malloc(16)

        # Standard Android JNINativeInterface slot indices
        jni_names = {
            6: "FindClass",
            15: "ExceptionCheck",
            17: "ExceptionClear",
            31: "GetObjectClass",
            33: "GetMethodID",
            94: "GetFieldID",
            113: "GetStaticMethodID",
            167: "NewStringUTF",
            168: "GetStringUTFLength",
            169: "GetStringUTFChars",
            170: "ReleaseStringUTFChars",
            171: "GetArrayLength",
            176: "NewByteArray",
            184: "GetByteArrayElements",
            192: "ReleaseByteArrayElements",
            196: "GetByteArrayRegion",
            204: "SetByteArrayRegion",
            215: "RegisterNatives",
        }
        for idx in range(240):
            fn_va = jni_stub_base + idx * 8
            self.mu.mem_write(fn_va, struct.pack("<I", 0xD65F03C0))  # ret
            self.mu.mem_write(vtable_addr + idx * 8, struct.pack("<Q", fn_va))
            self.jni_slot_to_name[fn_va] = jni_names.get(idx, f"JNI_slot_{idx}")

        self.mu.hook_add(self.uc.UC_HOOK_CODE, self._on_code_hook, begin=self.STUB_BASE, end=self.STUB_BASE + self.STUB_SIZE)

    def _on_code_hook(self, mu, address: int, _size: int, _user_data) -> None:
        if address == self.STOP_ADDR:
            mu.emu_stop()
            return
        if address in self.stub_addr_to_name:
            self._handle_libc_call(mu, self.stub_addr_to_name[address])
        elif address in self.jni_slot_to_name:
            self._handle_jni_call(mu, self.jni_slot_to_name[address])

    def _handle_libc_call(self, mu, name: str) -> None:
        x0 = mu.reg_read(self.a64.UC_ARM64_REG_X0)
        x1 = mu.reg_read(self.a64.UC_ARM64_REG_X1)
        x2 = mu.reg_read(self.a64.UC_ARM64_REG_X2)
        base = name.split("@")[0]

        if base == "strlen":
            res = len(self.read_cstr(x0))
            mu.reg_write(self.a64.UC_ARM64_REG_X0, res)
        elif base in ("strcpy", "strncpy"):
            s = self.read_cstr(x1, x2 if base == "strncpy" else 4096)
            out = s.ljust(x2, b"\x00") if base == "strncpy" else s + b"\x00"
            mu.mem_write(x0, out)
        elif base == "strcat":
            dst_s = self.read_cstr(x0)
            src_s = self.read_cstr(x1)
            mu.mem_write(x0 + len(dst_s), src_s + b"\x00")
        elif base == "strdup":
            s = self.read_cstr(x0)
            mu.reg_write(self.a64.UC_ARM64_REG_X0, self.alloc_cstr(s))
        elif base in ("strcmp", "strncmp"):
            max_n = x2 if base == "strncmp" else 4096
            s0 = self.read_cstr(x0, max_n)[:max_n]
            s1 = self.read_cstr(x1, max_n)[:max_n]
            cmp_v = 0 if s0 == s1 else (1 if s0 > s1 else 0xFFFFFFFFFFFFFFFF)
            mu.reg_write(self.a64.UC_ARM64_REG_X0, cmp_v)
        elif base in ("memcpy", "memmove"):
            if x2 > 0:
                data = bytes(mu.mem_read(x1, x2))
                mu.mem_write(x0, data)
        elif base == "memset":
            if x2 > 0:
                mu.mem_write(x0, bytes([x1 & 0xFF]) * x2)
        elif base == "memcmp":
            b0 = bytes(mu.mem_read(x0, x2))
            b1 = bytes(mu.mem_read(x1, x2))
            cmp_v = 0 if b0 == b1 else (1 if b0 > b1 else 0xFFFFFFFFFFFFFFFF)
            mu.reg_write(self.a64.UC_ARM64_REG_X0, cmp_v)
        elif base == "malloc":
            mu.reg_write(self.a64.UC_ARM64.UC_ARM64_REG_X0 if hasattr(self.a64, "UC_ARM64") else self.a64.UC_ARM64_REG_X0, self.malloc(x0))
        elif base == "calloc":
            total = x0 * x1
            p = self.malloc(total)
            if total > 0:
                mu.mem_write(p, b"\x00" * total)
            mu.reg_write(self.a64.UC_ARM64_REG_X0, p)
        elif base == "free":
            mu.reg_write(self.a64.UC_ARM64_REG_X0, 0)
        elif base in ("__stack_chk_fail", "abort"):
            mu.emu_stop()
        else:
            mu.reg_write(self.a64.UC_ARM64_REG_X0, 0)

        if self.trace_calls:
            ret_x0 = mu.reg_read(self.a64.UC_ARM64_REG_X0)
            print(f"  [libc] {base}(0x{x0:x}, 0x{x1:x}, 0x{x2:x}) -> 0x{ret_x0:x}")

    def _handle_jni_call(self, mu, name: str) -> None:
        # x0 is JNIEnv*, x1/x2/x3/x4 are JNI args
        x1 = mu.reg_read(self.a64.UC_ARM64_REG_X1)
        x2 = mu.reg_read(self.a64.UC_ARM64_REG_X2)
        x3 = mu.reg_read(self.a64.UC_ARM64_REG_X3)
        x4 = mu.reg_read(self.a64.UC_ARM64_REG_X4)

        if name == "GetStringUTFChars":
            h = self.handles.get(x1)
            c_ptr = h["c_ptr"] if h else x1
            if x2 != 0:
                mu.mem_write(x2, b"\x00")
            mu.reg_write(self.a64.UC_ARM64_REG_X0, c_ptr)
        elif name == "GetStringUTFLength":
            h = self.handles.get(x1)
            ln = len(h["bytes"]) if h else len(self.read_cstr(x1))
            mu.reg_write(self.a64.UC_ARM64_REG_X0, ln)
        elif name == "NewStringUTF":
            s_bytes = self.read_cstr(x1)
            mu.reg_write(self.a64.UC_ARM64_REG_X0, self.alloc_jstring(s_bytes))
        elif name == "GetArrayLength":
            h = self.handles.get(x1)
            mu.reg_write(self.a64.UC_ARM64_REG_X0, h["len"] if h else 0)
        elif name == "GetByteArrayElements":
            h = self.handles.get(x1)
            if x2 != 0:
                mu.mem_write(x2, b"\x00")
            mu.reg_write(self.a64.UC_ARM64_REG_X0, h["c_ptr"] if h else x1)
        elif name == "ReleaseByteArrayElements":
            h = self.handles.get(x1)
            if h and x2 != 0 and h["len"] > 0:
                h["bytes"] = bytearray(mu.mem_read(x2, h["len"]))
            mu.reg_write(self.a64.UC_ARM64_REG_X0, 0)
        elif name == "NewByteArray":
            mu.reg_write(self.a64.UC_ARM64_REG_X0, self.alloc_jbytearray(b"\x00" * x1))
        elif name == "SetByteArrayRegion":
            # (env, array=x1, start=x2, len=x3, buf=x4)
            h = self.handles.get(x1)
            if h and x3 > 0:
                chunk = bytes(mu.mem_read(x4, x3))
                h["bytes"][x2 : x2 + x3] = chunk
                mu.mem_write(h["c_ptr"] + x2, chunk)
            mu.reg_write(self.a64.UC_ARM64_REG_X0, 0)
        elif name == "GetByteArrayRegion":
            h = self.handles.get(x1)
            if h and x3 > 0:
                chunk = bytes(h["bytes"][x2 : x2 + x3])
                mu.mem_write(x4, chunk)
            mu.reg_write(self.a64.UC_ARM64_REG_X0, 0)
        else:
            mu.reg_write(self.a64.UC_ARM64_REG_X0, 0)

        if self.trace_calls:
            ret_x0 = mu.reg_read(self.a64.UC_ARM64_REG_X0)
            print(f"  [JNI] {name}(0x{x1:x}, 0x{x2:x}, 0x{x3:x}) -> 0x{ret_x0:x}")

    def call_function(self, vaddr: int, args: list[int], max_insns: int = 500000) -> int:
        arg_regs = [
            self.a64.UC_ARM64_REG_X0,
            self.a64.UC_ARM64_REG_X1,
            self.a64.UC_ARM64_REG_X2,
            self.a64.UC_ARM64_REG_X3,
            self.a64.UC_ARM64_REG_X4,
            self.a64.UC_ARM64_REG_X5,
            self.a64.UC_ARM64_REG_X6,
            self.a64.UC_ARM64_REG_X7,
        ]
        for i, val in enumerate(args[:8]):
            self.mu.reg_write(arg_regs[i], val & 0xFFFFFFFFFFFFFFFF)
        self.mu.reg_write(self.a64.UC_ARM64_REG_LR, self.STOP_ADDR)
        self.mu.emu_start(vaddr, self.STOP_ADDR, count=max_insns)
        return self.mu.reg_read(self.a64.UC_ARM64_REG_X0)


def parse_arg_spec(harness: Arm64JniHarness, spec: str, jni_mode: bool) -> int:
    if spec.startswith("int:"):
        return int(spec[4:], 0)
    if spec.startswith("str:"):
        s = spec[4:]
        return harness.alloc_jstring(s) if jni_mode else harness.alloc_cstr(s)
    if spec.startswith("hex:"):
        b = bytes.fromhex(spec[4:])
        return harness.alloc_jbytearray(b) if jni_mode else harness.alloc_cstr(b)
    if spec.startswith("file:"):
        b = Path(spec[5:]).read_bytes()
        return harness.alloc_jbytearray(b) if jni_mode else harness.alloc_cstr(b)
    if spec.startswith("outbuf:"):
        sz = int(spec[7:], 0)
        p = harness.malloc(sz)
        harness.mu.mem_write(p, b"\x00" * sz)
        return p
    return int(spec, 0)


def main() -> int:
    ap = argparse.ArgumentParser(description="Unicorn ARM64 ELF (.so) & JNI function emulator with auto-relocation and libc/JNI stubs.")
    ap.add_argument("elf", type=Path, help="Path to ARM64 .so file")
    ap.add_argument("--init-call", action="append", default=[], metavar="VADDR", help="Call setup/init function(s) before target function (e.g. 0x1178)")
    ap.add_argument("--call", default="", metavar="VADDR", help="Call normal C function at vaddr (e.g. 0x3470)")
    ap.add_argument("--jni-call", default="", metavar="VADDR", help="Call JNI function at vaddr (auto-passes x0=JNIEnv*, x1=thiz)")
    ap.add_argument("--arg", action="append", default=[], metavar="SPEC", help="Function argument: int:0x10, str:hello, hex:deadbeef, file:a.bin, outbuf:256")
    ap.add_argument("--dump", action="append", default=[], metavar="SPEC", help="Dump memory/result after call: 0xc238:64, x0:64, ret:jstring, ret:jbytearray")
    ap.add_argument("--trace-calls", action="store_true", help="Log all libc PLT and JNI calls during emulation")
    ap.add_argument("--max-insns", type=int, default=500000, help="Max instructions per call (default: 500000)")
    args = ap.parse_args()

    h = Arm64JniHarness(args.elf, trace_calls=args.trace_calls)

    for init_s in args.init_call:
        init_va = int(init_s, 0)
        print(f"[+] Running --init-call 0x{init_va:x} ...")
        h.call_function(init_va, [], max_insns=args.max_insns)

    ret_val = 0
    if args.call or args.jni_call:
        jni_mode = bool(args.jni_call)
        target_s = args.jni_call if jni_mode else args.call
        target_va = int(target_s, 0)
        call_args: list[int] = [h.jni_env_ptr, h.thiz_obj] if jni_mode else []
        for a_spec in args.arg:
            call_args.append(parse_arg_spec(h, a_spec, jni_mode))
        print(f"[+] Emulating {'JNI' if jni_mode else 'C'} function @ 0x{target_va:x} with args={[hex(x) for x in call_args]}")
        ret_val = h.call_function(target_va, call_args, max_insns=args.max_insns)
        print(f"[=] Return x0 = 0x{ret_val:x} ({ret_val})")

    for d_spec in args.dump:
        if d_spec == "ret:jstring":
            info = h.handles.get(ret_val)
            raw_b = info["bytes"] if info else h.read_cstr(ret_val)
            print(f"[Dump ret:jstring ({len(raw_b)}B)] hex={raw_b.hex()} utf8={raw_b.decode('utf-8', errors='replace')!r}")
        elif d_spec == "ret:jbytearray":
            info = h.handles.get(ret_val)
            raw_b = bytes(info["bytes"]) if info else b""
            print(f"[Dump ret:jbytearray ({len(raw_b)}B)] hex={raw_b[:128].hex()}")
            print(f"  ascii={raw_b[:128].decode('utf-8', errors='replace')!r}")
        elif ":" in d_spec:
            loc_s, len_s = d_spec.split(":", 1)
            ln = int(len_s, 0)
            addr = ret_val if loc_s.lower() == "x0" else int(loc_s, 0)
            # If addr is an unmapped ELF file/vaddr, also check if it's in PT_LOAD
            blob = bytes(h.mu.mem_read(addr, ln))
            cstr = blob.split(b"\x00", 1)[0]
            print(f"[Dump 0x{addr:x} ({ln}B)]")
            print(f"  hex  : {blob.hex()}")
            print(f"  cstr : {cstr.hex()} ({len(cstr)}B) ascii={cstr.decode('utf-8', errors='replace')!r}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
