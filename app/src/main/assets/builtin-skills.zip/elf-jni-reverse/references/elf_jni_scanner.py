#!/usr/bin/env python3
"""Pure-stdlib ELF32/ELF64 & ARM64 JNI Analyzer, Relocation Engine, RegisterNatives Recoverer & Xref Tool.

Eliminates common native reverse-engineering pitfalls:
1. Works even when ELF section headers are stripped (falls back to PT_LOAD + PT_DYNAMIC)
2. Accurately maps virtual addresses <-> file offsets across PT_LOAD segments (e.g. .data vaddr 0xc000 -> off 0x8000)
3. Applies .rela.dyn (R_AARCH64_RELATIVE / GLOB_DAT / ABS64) and .rela.plt (R_AARCH64_JUMP_SLOT) relocations in memory
4. Automatically recovers RegisterNatives `JNINativeMethod` tables ({namePtr, sigPtr, fnPtr}) after relocations
5. Scans ARM64 executable segments for `ADRP + ADD` / `ADRP + LDR` (including GOT indirection) and `BL` cross-references (--xref)
6. Disassembles ARM64 functions (--disasm <vaddr>) with automatic string, GOT, and PLT call annotations
7. Patches ARM64 functions by virtual address (--patch-ret <vaddr> --val <0|1|nop>)
"""

from __future__ import annotations

import argparse
import re
import struct
import sys
from pathlib import Path

EM_NAMES = {
    3: "EM_386",
    40: "EM_ARM",
    62: "EM_X86_64",
    183: "EM_AARCH64",
}

PT_LOAD = 1
PT_DYNAMIC = 2

DT_NULL = 0
DT_NEEDED = 1
DT_PLTRELSZ = 2
DT_PLTGOT = 3
DT_STRTAB = 5
DT_SYMTAB = 6
DT_RELA = 7
DT_RELASZ = 8
DT_STRSZ = 10
DT_JMPREL = 23

R_AARCH64_ABS64 = 257
R_AARCH64_GLOB_DAT = 1025
R_AARCH64_JUMP_SLOT = 1026
R_AARCH64_RELATIVE = 1027

JNI_SIG_RE = re.compile(rb"^\([\[A-Za-z0-9_/;]*\)[VZBCSIJFDL\[][A-Za-z0-9_/;$]*$")
IDENT_RE = re.compile(rb"^[A-Za-z_$][A-Za-z0-9_$]{0,127}$")


def sign_extend(val: int, bits: int) -> int:
    sign_bit = 1 << (bits - 1)
    return (val & (sign_bit - 1)) - (val & sign_bit)


class ElfImage:
    def __init__(self, data: bytes) -> None:
        self.raw = data
        if len(data) < 52 or not data.startswith(b"\x7fELF"):
            raise ValueError("Not a valid ELF binary")

        self.ei_class = data[4]
        self.ei_data = data[5]
        self.endian = "<" if self.ei_data == 1 else ">"
        self.is_64 = self.ei_class == 2

        if self.is_64:
            (
                self.e_type,
                self.e_machine,
                _e_version,
                self.e_entry,
                self.e_phoff,
                self.e_shoff,
                _e_flags,
                _e_ehsize,
                self.e_phentsize,
                self.e_phnum,
                self.e_shentsize,
                self.e_shnum,
                self.e_shstrndx,
            ) = struct.unpack_from(f"{self.endian}HHIQQQIHHHHHH", data, 16)
        else:
            (
                self.e_type,
                self.e_machine,
                _e_version,
                self.e_entry,
                self.e_phoff,
                self.e_shoff,
                _e_flags,
                _e_ehsize,
                self.e_phentsize,
                self.e_phnum,
                self.e_shentsize,
                self.e_shnum,
                self.e_shstrndx,
            ) = struct.unpack_from(f"{self.endian}HHIIIIIHHHHHH", data, 16)

        self.segments: list[dict] = []
        self.sections: list[dict] = []
        self.relocated = bytearray(data)
        self.got_symbols: dict[int, str] = {}
        self.plt_stubs: dict[int, str] = {}
        self.symbols: dict[int, str] = {}
        self.relocations: dict[int, int] = {}

        self._parse_program_headers()
        self._parse_sections()
        self._parse_dynamic_and_relocs()
        if self.e_machine == 183 and self.is_64:
            self._resolve_arm64_plt_stubs()

    def _parse_program_headers(self) -> None:
        data = self.raw
        for i in range(self.e_phnum):
            off = self.e_phoff + i * self.e_phentsize
            if off + self.e_phentsize > len(data):
                break
            if self.is_64:
                p_type, p_flags, p_offset, p_vaddr, _p_paddr, p_filesz, p_memsz, p_align = (
                    struct.unpack_from(f"{self.endian}IIQQQQQQ", data, off)
                )
            else:
                p_type, p_offset, p_vaddr, _p_paddr, p_filesz, p_memsz, p_flags, p_align = (
                    struct.unpack_from(f"{self.endian}8I", data, off)
                )
            self.segments.append(
                {
                    "type": p_type,
                    "flags": p_flags,
                    "offset": p_offset,
                    "vaddr": p_vaddr,
                    "filesz": p_filesz,
                    "memsz": p_memsz,
                    "align": p_align,
                }
            )

    def vaddr_to_offset(self, vaddr: int) -> int | None:
        for seg in self.segments:
            if seg["type"] == PT_LOAD:
                start = seg["vaddr"]
                end = start + seg["filesz"]
                if start <= vaddr < end:
                    off = seg["offset"] + (vaddr - start)
                    if 0 <= off < len(self.raw):
                        return off
        if 0 <= vaddr < len(self.raw):
            return vaddr
        return None

    def offset_to_vaddr(self, offset: int) -> int:
        for seg in self.segments:
            if seg["type"] == PT_LOAD:
                start = seg["offset"]
                end = start + seg["filesz"]
                if start <= offset < end:
                    return seg["vaddr"] + (offset - start)
        return offset

    def is_executable_vaddr(self, vaddr: int) -> bool:
        for seg in self.segments:
            if seg["type"] == PT_LOAD and (seg["flags"] & 0x1):  # PF_X
                if seg["vaddr"] <= vaddr < seg["vaddr"] + seg["filesz"]:
                    return True
        return False

    def read_cstr_vaddr(self, vaddr: int, max_len: int = 512) -> bytes | None:
        off = self.vaddr_to_offset(vaddr)
        if off is None or off < 0 or off >= len(self.relocated):
            return None
        end = self.relocated.find(b"\x00", off, min(len(self.relocated), off + max_len))
        if end < 0:
            return None
        return bytes(self.relocated[off:end])

    def _parse_sections(self) -> None:
        data = self.raw
        if self.e_shoff == 0 or self.e_shnum == 0 or self.e_shoff >= len(data):
            return
        raw_sh: list[tuple] = []
        for i in range(self.e_shnum):
            off = self.e_shoff + i * self.e_shentsize
            if off + self.e_shentsize > len(data):
                break
            if self.is_64:
                fields = struct.unpack_from(f"{self.endian}IIQQQQIIQQ", data, off)
            else:
                fields = struct.unpack_from(f"{self.endian}10I", data, off)
            raw_sh.append(fields)

        shstr = b""
        if 0 <= self.e_shstrndx < len(raw_sh):
            s_off, s_sz = raw_sh[self.e_shstrndx][4], raw_sh[self.e_shstrndx][5]
            if 0 <= s_off < len(data):
                shstr = data[s_off : s_off + s_sz]

        for fields in raw_sh:
            name_idx = fields[0]
            end = shstr.find(b"\x00", name_idx) if 0 <= name_idx < len(shstr) else -1
            name = shstr[name_idx:end].decode("utf-8", errors="replace") if end >= 0 else ""
            self.sections.append(
                {
                    "name": name,
                    "type": fields[1],
                    "flags": fields[2],
                    "vaddr": fields[3],
                    "offset": fields[4],
                    "size": fields[5],
                    "link": fields[6],
                    "entsize": fields[9],
                }
            )

    def _parse_dynamic_and_relocs(self) -> None:
        data = self.raw
        dyn_entries: list[tuple[int, int]] = []
        for seg in self.segments:
            if seg["type"] == PT_DYNAMIC:
                pos = seg["offset"]
                end = min(len(data), pos + seg["filesz"])
                step = 16 if self.is_64 else 8
                fmt = f"{self.endian}qQ" if self.is_64 else f"{self.endian}iI"
                while pos + step <= end:
                    d_tag, d_val = struct.unpack_from(fmt, data, pos)
                    if d_tag == DT_NULL:
                        break
                    dyn_entries.append((d_tag, d_val))
                    pos += step

        dyn_map = dict(dyn_entries)
        strtab_off = self.vaddr_to_offset(dyn_map.get(DT_STRTAB, 0)) if DT_STRTAB in dyn_map else None
        strtab_sz = dyn_map.get(DT_STRSZ, 0)
        symtab_off = self.vaddr_to_offset(dyn_map.get(DT_SYMTAB, 0)) if DT_SYMTAB in dyn_map else None

        dynstr = b""
        if strtab_off is not None and strtab_sz > 0:
            dynstr = data[strtab_off : strtab_off + strtab_sz]
        else:
            for s in self.sections:
                if s["name"] == ".dynstr":
                    dynstr = data[s["offset"] : s["offset"] + s["size"]]
                    break

        dynsyms: list[tuple[str, int, int]] = []
        sym_step = 24 if self.is_64 else 16
        for s in self.sections:
            if s["type"] in (2, 11):  # SHT_SYMTAB or SHT_DYNSYM
                s_str = b""
                if 0 <= s["link"] < len(self.sections):
                    ls = self.sections[s["link"]]
                    s_str = data[ls["offset"] : ls["offset"] + ls["size"]]
                pos = s["offset"]
                end = min(len(data), pos + s["size"])
                while pos + sym_step <= end:
                    if self.is_64:
                        st_name, st_info, _other, _shndx, st_val, st_sz = struct.unpack_from(
                            f"{self.endian}IBBHQQ", data, pos
                        )
                    else:
                        st_name, st_val, st_sz, st_info, _other, _shndx = struct.unpack_from(
                            f"{self.endian}IIIBBH", data, pos
                        )
                    nm = ""
                    if 0 <= st_name < len(s_str):
                        e_idx = s_str.find(b"\x00", st_name)
                        if e_idx >= 0:
                            nm = s_str[st_name:e_idx].decode("utf-8", errors="replace")
                    if nm and st_val > 0:
                        self.symbols[st_val] = nm
                    if s["type"] == 11:
                        dynsyms.append((nm, st_val, st_sz))
                    pos += sym_step

        if not dynsyms and symtab_off is not None and dynstr:
            # Stripped section header fallback for .dynsym
            max_end = strtab_off if (strtab_off and strtab_off > symtab_off) else min(len(data), symtab_off + 24 * 2048)
            pos = symtab_off
            while pos + sym_step <= max_end:
                if self.is_64:
                    st_name, _info, _other, _shndx, st_val, st_sz = struct.unpack_from(
                        f"{self.endian}IBBHQQ", data, pos
                    )
                else:
                    st_name, st_val, st_sz, _info, _other, _shndx = struct.unpack_from(
                        f"{self.endian}IIIBBH", data, pos
                    )
                nm = ""
                if 0 <= st_name < len(dynstr):
                    e_idx = dynstr.find(b"\x00", st_name)
                    if e_idx >= 0:
                        nm = dynstr[st_name:e_idx].decode("utf-8", errors="replace")
                if nm and st_val > 0:
                    self.symbols[st_val] = nm
                dynsyms.append((nm, st_val, st_sz))
                pos += sym_step

        if not self.is_64:
            return

        rela_ranges: list[tuple[int, int]] = []
        for s in self.sections:
            if s["type"] == 4:  # SHT_RELA
                rela_ranges.append((s["offset"], s["size"]))
        if not rela_ranges:
            for tag_off, tag_sz in ((DT_RELA, DT_RELASZ), (DT_JMPREL, DT_PLTRELSZ)):
                if tag_off in dyn_map and tag_sz in dyn_map:
                    roff = self.vaddr_to_offset(dyn_map[tag_off])
                    if roff is not None:
                        rela_ranges.append((roff, dyn_map[tag_sz]))

        for r_off_base, r_sz in rela_ranges:
            pos = r_off_base
            end = min(len(data), r_off_base + r_sz)
            while pos + 24 <= end:
                r_offset, r_info, r_addend = struct.unpack_from(f"{self.endian}QQq", data, pos)
                r_type = r_info & 0xFFFFFFFF
                r_sym = r_info >> 32
                target_file_off = self.vaddr_to_offset(r_offset)

                if r_type == R_AARCH64_RELATIVE:
                    val = r_addend & 0xFFFFFFFFFFFFFFFF
                    self.relocations[r_offset] = val
                    if target_file_off is not None and target_file_off + 8 <= len(self.relocated):
                        struct.pack_into("<Q", self.relocated, target_file_off, val)
                elif r_type in (R_AARCH64_GLOB_DAT, R_AARCH64_JUMP_SLOT, R_AARCH64_ABS64):
                    sym_name, sym_val, _ = dynsyms[r_sym] if 0 <= r_sym < len(dynsyms) else ("", 0, 0)
                    resolved = (sym_val + r_addend) & 0xFFFFFFFFFFFFFFFF if sym_val else 0
                    if resolved and target_file_off is not None and target_file_off + 8 <= len(self.relocated):
                        struct.pack_into("<Q", self.relocated, target_file_off, resolved)
                        self.relocations[r_offset] = resolved
                    if sym_name:
                        self.got_symbols[r_offset] = sym_name
                pos += 24

    def _resolve_arm64_plt_stubs(self) -> None:
        # Match standard ARM64 PLT stub pattern:
        # adrp x16, #page ; ldr x17, [x16, #off] ; add x16, x16, #off ; br x17
        for seg in self.segments:
            if seg["type"] != PT_LOAD or not (seg["flags"] & 0x1):
                continue
            start_off = seg["offset"]
            end_off = min(len(self.raw), start_off + seg["filesz"] - 16)
            for off in range(start_off, end_off, 4):
                i0, i1, i2, i3 = struct.unpack_from("<4I", self.raw, off)
                if (
                    (i0 & 0x9F00001F) == 0x90000010  # adrp x16, ...
                    and (i1 & 0xFFC003FF) == 0xF9400211  # ldr x17, [x16, #imm]
                    and i3 == 0xD61F0220  # br x17
                ):
                    stub_vaddr = seg["vaddr"] + (off - start_off)
                    immlo = (i0 >> 29) & 0x3
                    immhi = (i0 >> 5) & 0x7FFFF
                    page_off = sign_extend((immhi << 2) | immlo, 21) << 12
                    page_base = (stub_vaddr & ~0xFFF) + page_off
                    ldr_imm = ((i1 >> 10) & 0xFFF) << 3
                    got_vaddr = page_base + ldr_imm
                    if got_vaddr in self.got_symbols:
                        sym = self.got_symbols[got_vaddr]
                        self.plt_stubs[stub_vaddr] = f"{sym}@plt"
                        self.symbols[stub_vaddr] = f"{sym}@plt"

    def recover_register_natives(self) -> list[dict]:
        """Scan relocated image for JNINativeMethod triples: {const char* name, const char* sig, void* fnPtr}."""
        if not self.is_64:
            return []
        methods: list[dict] = []
        seen: set[tuple[str, str, int]] = set()
        for seg in self.segments:
            if seg["type"] != PT_LOAD:
                continue
            start_off = seg["offset"]
            end_off = min(len(self.relocated), start_off + seg["filesz"] - 24)
            for off in range(start_off, end_off, 8):
                name_ptr, sig_ptr, fn_ptr = struct.unpack_from("<3Q", self.relocated, off)
                if name_ptr == 0 or sig_ptr == 0 or fn_ptr == 0:
                    continue
                fn_clean = fn_ptr & ~1
                if not self.is_executable_vaddr(fn_clean):
                    continue
                sig_b = self.read_cstr_vaddr(sig_ptr, 256)
                if not sig_b or not JNI_SIG_RE.match(sig_b):
                    continue
                name_b = self.read_cstr_vaddr(name_ptr, 128)
                if not name_b or not IDENT_RE.match(name_b):
                    continue
                nm = name_b.decode("ascii", errors="replace")
                sg = sig_b.decode("ascii", errors="replace")
                key = (nm, sg, fn_clean)
                if key in seen:
                    continue
                seen.add(key)
                methods.append(
                    {
                        "table_vaddr": seg["vaddr"] + (off - start_off),
                        "table_off": off,
                        "name": nm,
                        "signature": sg,
                        "fn_vaddr": fn_clean,
                        "fn_off": self.vaddr_to_offset(fn_clean) or 0,
                    }
                )
        return methods

    def scan_arm64_xrefs(self, query: str = "") -> list[dict]:
        """Scan all executable segments for ADRP+ADD, ADRP+LDR (including GOT), and BL references."""
        if not self.is_64 or self.e_machine != 183:
            return []
        q = query.lower()
        q_addr: int | None = None
        if q.startswith("0x"):
            try:
                q_addr = int(q, 16)
            except ValueError:
                pass

        hits: list[dict] = []
        for seg in self.segments:
            if seg["type"] != PT_LOAD or not (seg["flags"] & 0x1):
                continue
            start_off = seg["offset"]
            end_off = min(len(self.relocated), start_off + seg["filesz"] - 4)
            # Track recent ADRP page per register (within 8-instruction window)
            adrp_state: dict[int, tuple[int, int]] = {}

            for off in range(start_off, end_off, 4):
                vaddr = seg["vaddr"] + (off - start_off)
                (insn,) = struct.unpack_from("<I", self.relocated, off)

                # Expire old ADRP tracking (> 32 bytes away)
                expired = [r for r, (_pg, a_va) in adrp_state.items() if vaddr - a_va > 32]
                for r in expired:
                    del adrp_state[r]

                # 1. ADRP Xd, #page
                if (insn & 0x9F000000) == 0x90000000:
                    rd = insn & 0x1F
                    immlo = (insn >> 29) & 0x3
                    immhi = (insn >> 5) & 0x7FFFF
                    page_off = sign_extend((immhi << 2) | immlo, 21) << 12
                    page_base = (vaddr & ~0xFFF) + page_off
                    adrp_state[rd] = (page_base, vaddr)
                    continue

                # 2. ADD Xd, Xn, #imm12 (64-bit)
                if (insn & 0xFF800000) == 0x91000000:
                    rd = insn & 0x1F
                    rn = (insn >> 5) & 0x1F
                    imm12 = (insn >> 10) & 0xFFF
                    sh = (insn >> 22) & 0x1
                    if sh:
                        imm12 <<= 12
                    if rn in adrp_state:
                        target_va = adrp_state[rn][0] + imm12
                        self._record_xref(hits, vaddr, off, f"adrp+add x{rd}", target_va, q, q_addr)
                    continue

                # 3. LDR Xt, [Xn, #imm12*8] (64-bit unsigned offset)
                if (insn & 0xFFC00000) == 0xF9400000:
                    rt = insn & 0x1F
                    rn = (insn >> 5) & 0x1F
                    imm12 = ((insn >> 10) & 0xFFF) << 3
                    if rn in adrp_state:
                        ptr_va = adrp_state[rn][0] + imm12
                        deref_va = self.relocations.get(ptr_va)
                        if deref_va is None:
                            p_off = self.vaddr_to_offset(ptr_va)
                            if p_off is not None and p_off + 8 <= len(self.relocated):
                                (deref_va,) = struct.unpack_from("<Q", self.relocated, p_off)
                        if deref_va:
                            self._record_xref(
                                hits,
                                vaddr,
                                off,
                                f"adrp+ldr x{rt} [0x{ptr_va:x}]->",
                                deref_va,
                                q,
                                q_addr,
                            )
                        else:
                            self._record_xref(hits, vaddr, off, f"adrp+ldr x{rt}", ptr_va, q, q_addr)
                    continue

                # 4. BL #imm26
                if (insn & 0xFC000000) == 0x94000000:
                    imm26 = sign_extend(insn & 0x03FFFFFF, 26) << 2
                    callee_va = vaddr + imm26
                    self._record_xref(hits, vaddr, off, "bl", callee_va, q, q_addr)

        return hits

    def _record_xref(
        self,
        hits: list[dict],
        insn_va: int,
        insn_off: int,
        kind: str,
        target_va: int,
        q: str,
        q_addr: int | None,
    ) -> None:
        sym = self.symbols.get(target_va) or self.got_symbols.get(target_va) or ""
        s_preview = ""
        cstr = self.read_cstr_vaddr(target_va, 160)
        if cstr and len(cstr) >= 2:
            try:
                decoded = cstr.decode("utf-8")
                if all(ch.isprintable() or ch in "\t\r\n" for ch in decoded):
                    s_preview = decoded
            except UnicodeDecodeError:
                pass
        if not s_preview and not sym and q and q_addr is None:
            return
        desc = f"0x{target_va:x}"
        if sym:
            desc += f" <{sym}>"
        if s_preview:
            desc += f" {s_preview!r}"
        if q_addr is not None:
            if target_va != q_addr:
                return
        elif q and q not in desc.lower():
            return
        hits.append({"vaddr": insn_va, "off": insn_off, "kind": kind, "target": target_va, "desc": desc})


def decode_arm64_single(insn: int, vaddr: int) -> str:
    if insn == 0xD65F03C0:
        return "ret"
    if insn == 0xD503201F:
        return "nop"
    if (insn & 0x9F000000) == 0x90000000:
        rd = insn & 0x1F
        immlo = (insn >> 29) & 0x3
        immhi = (insn >> 5) & 0x7FFFF
        page = (vaddr & ~0xFFF) + (sign_extend((immhi << 2) | immlo, 21) << 12)
        return f"adrp x{rd}, #0x{page:x}"
    if (insn & 0xFF800000) == 0x91000000:
        rd = insn & 0x1F
        rn = (insn >> 5) & 0x1F
        imm12 = ((insn >> 10) & 0xFFF) << (12 if ((insn >> 22) & 1) else 0)
        return f"add x{rd}, x{rn}, #0x{imm12:x}"
    if (insn & 0xFFC00000) == 0xF9400000:
        rt = insn & 0x1F
        rn = (insn >> 5) & 0x1F
        imm12 = ((insn >> 10) & 0xFFF) << 3
        return f"ldr x{rt}, [x{rn}, #0x{imm12:x}]"
    if (insn & 0xFC000000) == 0x94000000:
        target = vaddr + (sign_extend(insn & 0x03FFFFFF, 26) << 2)
        return f"bl #0x{target:x}"
    if (insn & 0xFC000000) == 0x14000000:
        target = vaddr + (sign_extend(insn & 0x03FFFFFF, 26) << 2)
        return f"b #0x{target:x}"
    if (insn & 0x7F800000) == 0x52800000:
        sf = "x" if (insn >> 31) else "w"
        rd = insn & 0x1F
        imm16 = (insn >> 5) & 0xFFFF
        hw = ((insn >> 21) & 0x3) * 16
        return f"movz {sf}{rd}, #0x{imm16:x}, lsl #{hw}"
    if (insn & 0x7F800000) == 0x72800000:
        sf = "x" if (insn >> 31) else "w"
        rd = insn & 0x1F
        imm16 = (insn >> 5) & 0xFFFF
        hw = ((insn >> 21) & 0x3) * 16
        return f"movk {sf}{rd}, #0x{imm16:x}, lsl #{hw}  ; sets bits [{hw+15}:{hw}]"
    return f".inst 0x{insn:08x}"


def disasm_arm64_range(elf: ElfImage, start_vaddr: int, count: int = 60) -> list[str]:
    off = elf.vaddr_to_offset(start_vaddr)
    if off is None:
        return [f"Invalid vaddr 0x{start_vaddr:x} (not mapped in PT_LOAD)"]
    code = bytes(elf.relocated[off : off + count * 4])

    # Pre-index annotations for this range
    adrp_pages: dict[int, int] = {}
    notes: dict[int, str] = {}
    for i in range(0, len(code) - 3, 4):
        va = start_vaddr + i
        (insn,) = struct.unpack_from("<I", code, i)
        if (insn & 0x9F000000) == 0x90000000:
            rd = insn & 0x1F
            immlo = (insn >> 29) & 0x3
            immhi = (insn >> 5) & 0x7FFFF
            adrp_pages[rd] = (va & ~0xFFF) + (sign_extend((immhi << 2) | immlo, 21) << 12)
        elif (insn & 0xFF800000) == 0x91000000:
            rd = insn & 0x1F
            rn = (insn >> 5) & 0x1F
            imm12 = ((insn >> 10) & 0xFFF) << (12 if ((insn >> 22) & 1) else 0)
            if rn in adrp_pages:
                t_va = adrp_pages[rn] + imm12
                cstr = elf.read_cstr_vaddr(t_va, 120)
                s_txt = f" -> {cstr.decode('utf-8', errors='replace')!r}" if cstr else ""
                notes[va] = f"; target=0x{t_va:x}{s_txt}"
                adrp_pages[rd] = t_va
        elif (insn & 0xFFC00000) == 0xF9400000:
            rn = (insn >> 5) & 0x1F
            imm12 = ((insn >> 10) & 0xFFF) << 3
            if rn in adrp_pages:
                ptr_va = adrp_pages[rn] + imm12
                deref = elf.relocations.get(ptr_va)
                sym = elf.got_symbols.get(ptr_va, "")
                cstr = elf.read_cstr_vaddr(deref, 120) if deref else None
                extra = f" -> 0x{deref:x}" if deref else ""
                if sym:
                    extra += f" <{sym}>"
                if cstr:
                    extra += f" {cstr.decode('utf-8', errors='replace')!r}"
                notes[va] = f"; [0x{ptr_va:x}]{extra}"
        elif (insn & 0xFC000000) in (0x94000000, 0x14000000):
            t_va = va + (sign_extend(insn & 0x03FFFFFF, 26) << 2)
            sym = elf.symbols.get(t_va, "")
            if sym:
                notes[va] = f"; <{sym}>"

    lines: list[str] = []
    try:
        import capstone  # type: ignore

        md = capstone.Cs(capstone.CS_ARCH_ARM64, capstone.CS_MODE_LITTLE_ENDIAN)
        for ins in md.disasm(code, start_vaddr):
            f_off = elf.vaddr_to_offset(ins.address) or 0
            note = f"  {notes[ins.address]}" if ins.address in notes else ""
            lines.append(
                f"  0x{ins.address:06x} (off=0x{f_off:06x}): {ins.bytes.hex():<8}  {ins.mnemonic:<8} {ins.op_str}{note}"
            )
        return lines
    except ImportError:
        for i in range(0, len(code) - 3, 4):
            va = start_vaddr + i
            f_off = off + i
            (insn,) = struct.unpack_from("<I", code, i)
            txt = decode_arm64_single(insn, va)
            note = f"  {notes[va]}" if va in notes else ""
            lines.append(f"  0x{va:06x} (off=0x{f_off:06x}): {code[i:i+4].hex():<8}  {txt}{note}")
        return lines


def patch_arm64_function(raw: bytes, elf: ElfImage, vaddr: int, mode: str) -> tuple[bytes, str]:
    f_off = elf.vaddr_to_offset(vaddr)
    if f_off is None:
        raise ValueError(f"vaddr 0x{vaddr:x} does not map to any PT_LOAD file offset")
    patches = {
        "0": bytes.fromhex("00008052c0035fd6"),  # mov w0, #0 ; ret
        "1": bytes.fromhex("20008052c0035fd6"),  # mov w0, #1 ; ret
        "nop": bytes.fromhex("1f2003d5"),  # nop
    }
    patch_b = patches[mode]
    buf = bytearray(raw)
    old_b = bytes(buf[f_off : f_off + len(patch_b)])
    buf[f_off : f_off + len(patch_b)] = patch_b
    return bytes(buf), f"Patched vaddr=0x{vaddr:x} (file_off=0x{f_off:x}): {old_b.hex()} -> {patch_b.hex()} ({mode})"


def main() -> int:
    ap = argparse.ArgumentParser(description="Inspect ELF segments, relocations, JNI exports, RegisterNatives tables, and ARM64 xrefs.")
    ap.add_argument("elf", type=Path, help="Path to .so or ELF binary")
    ap.add_argument("--xref", default=None, metavar="QUERY", help="Search ARM64 ADRP+ADD / ADRP+LDR / BL xrefs (use '' for all string xrefs)")
    ap.add_argument("--disasm", default="", metavar="VADDR", help="Disassemble ARM64 instructions at vaddr (e.g. 0x1818) or symbol name")
    ap.add_argument("--len", type=int, default=60, help="Instruction count for --disasm (default: 60)")
    ap.add_argument("--limit", type=int, default=60, help="Max rows to print for tables/xrefs (default: 60)")
    ap.add_argument("--patch-ret", default="", metavar="VADDR", help="Patch ARM64 instruction/function at vaddr")
    ap.add_argument("--val", choices=["0", "1", "nop"], default="1", help="Patch value for --patch-ret")
    ap.add_argument("-o", "--output", type=Path, help="Output file for --patch-ret")
    args = ap.parse_args()

    raw = args.elf.read_bytes()
    elf = ElfImage(raw)

    if args.patch_ret:
        va = int(args.patch_ret, 0)
        patched, msg = patch_arm64_function(raw, elf, va, args.val)
        out = args.output or args.elf
        out.write_bytes(patched)
        print(f"{msg} -> {out}")
        return 0

    print(
        f"ELF class={'64' if elf.is_64 else '32'} "
        f"machine={EM_NAMES.get(elf.e_machine, elf.e_machine)} type={elf.e_type} "
        f"entry=0x{elf.e_entry:x} bytes={len(raw)} relocs={len(elf.relocations)} plt_stubs={len(elf.plt_stubs)}"
    )
    print(
        "[Toolkit] Use --xref <query> for ADRP+ADD/LDR xrefs, --disasm <vaddr> for annotated ARM64 disasm, "
        "or unicorn_arm64_harness.py (--init-call / --call / --jni-call / --dump) to emulate ARM64/JNI functions."
    )

    print("\n[PT_LOAD Segments (vaddr <-> file_offset)]")
    for seg in elf.segments:
        if seg["type"] == PT_LOAD:
            fl = seg["flags"]
            perm = f"{'R' if fl & 4 else '-'}{'W' if fl & 2 else '-'}{'X' if fl & 1 else '-'}"
            delta = seg["vaddr"] - seg["offset"]
            print(
                f"  vaddr=0x{seg['vaddr']:08x}..0x{seg['vaddr']+seg['memsz']:08x} "
                f"file_off=0x{seg['offset']:08x}..0x{seg['offset']+seg['filesz']:08x} "
                f"({perm}, vaddr-off=0x{delta:x})"
            )

    if elf.sections:
        print("\n[Sections]")
        for s in elf.sections:
            if s["name"]:
                print(f"  {s['name']:<18} vaddr=0x{s['vaddr']:08x} off=0x{s['offset']:08x} size=0x{s['size']:x}")
    else:
        print("\n[Sections: STRIPPED (e_shnum=0; using PT_LOAD + PT_DYNAMIC)]")

    jni_syms = [
        (va, nm)
        for va, nm in sorted(elf.symbols.items())
        if nm.startswith("Java_") or "JNI_OnLoad" in nm or "RegisterNatives" in nm
    ]
    print("\n[JNI / RegisterNatives Symbols]")
    for va, nm in jni_syms[: args.limit]:
        foff = elf.vaddr_to_offset(va) or 0
        print(f"  {nm} @ vaddr=0x{va:x} (file_off=0x{foff:x})")
    if not jni_syms:
        print("  (no exported Java_*/JNI_OnLoad symbols; checking relocated RegisterNatives tables below)")

    reg_methods = elf.recover_register_natives()
    if reg_methods:
        print(f"\n[Recovered RegisterNatives (JNINativeMethod) Table: {len(reg_methods)} methods]")
        for m in reg_methods[: args.limit]:
            print(
                f"  table@0x{m['table_vaddr']:x} (off=0x{m['table_off']:x}): "
                f"{m['name']}{m['signature']} -> fn_vaddr=0x{m['fn_vaddr']:x} (file_off=0x{m['fn_off']:x})"
            )
    else:
        # Fallback: scan raw JNI signature hints
        sig_pat = re.compile(rb"\([\[A-Za-z0-9_/;]*\)[VZBCSIJFDL\[][A-Za-z0-9_/;$]*")
        sigs = []
        for m in sig_pat.finditer(raw):
            s = m.group(0).decode("ascii", errors="ignore")
            if 3 <= len(s) <= 120:
                sigs.append((m.start(), elf.offset_to_vaddr(m.start()), s))
            if len(sigs) >= 30:
                break
        if sigs:
            print(f"\n[JNI Signature Hints (first {len(sigs)})]")
            for off, va, s in sigs:
                print(f"  vaddr=0x{va:x} (off=0x{off:x}) {s}")

    if args.xref is not None:
        xrefs = elf.scan_arm64_xrefs(args.xref)
        print(f"\n[ARM64 Cross-References matching '{args.xref}': {len(xrefs)} hits]")
        for x in xrefs[: args.limit]:
            print(f"  0x{x['vaddr']:06x} (off=0x{x['off']:06x}): {x['kind']:<18} -> {x['desc']}")

    if args.disasm:
        target_va = None
        if args.disasm.startswith("0x") or args.disasm.isdigit():
            target_va = int(args.disasm, 0)
        else:
            for va, nm in elf.symbols.items():
                if args.disasm.lower() in nm.lower():
                    target_va = va
                    break
            if target_va is None:
                for m in reg_methods:
                    if args.disasm.lower() == m["name"].lower():
                        target_va = m["fn_vaddr"]
                        break
        if target_va is None:
            print(f"\nCould not resolve disasm target '{args.disasm}'", file=sys.stderr)
            return 1
        print(f"\n[Disassembly @ vaddr=0x{target_va:x} ({args.len} instructions)]")
        for line in disasm_arm64_range(elf, target_va, args.len):
            print(line)

    return 0


if __name__ == "__main__":
    sys.exit(main())
