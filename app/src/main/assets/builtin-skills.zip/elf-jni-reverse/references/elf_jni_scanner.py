#!/usr/bin/env python3
"""Pure-stdlib ELF64/ELF32 JNI export, section, and RegisterNatives hint scanner."""

from __future__ import annotations

import argparse
import re
import struct
import sys
from pathlib import Path

EM_NAMES = {
    3: "EM_386",
    40: "EM_ARM",
    62: "EM_X86_64",
    183: "EM_AARCH64",
}


def scan_elf(path: Path) -> None:
    data = path.read_bytes()
    if len(data) < 52 or not data.startswith(b"\x7fELF"):
        raise ValueError(f"Not an ELF file: {path}")

    ei_class = data[4]
    ei_data = data[5]
    endian = "<" if ei_data == 1 else ">"

    if ei_class == 2:
        e_type, e_machine, _, e_entry, e_phoff, e_shoff, _, _, _, _, _, e_shnum, e_shstrndx = (
            struct.unpack_from(f"{endian}HHIQQQIHHHHHH", data, 16)
        )
        sh_fmt = f"{endian}IIQQQQIIQQ"
        sh_size = 64
        sym_fmt = f"{endian}IBBHQQ"
        sym_size = 24
    else:
        e_type, e_machine, _, e_entry, e_phoff, e_shoff, _, _, _, _, _, e_shnum, e_shstrndx = (
            struct.unpack_from(f"{endian}HHIIIIIHHHHHH", data, 16)
        )
        sh_fmt = f"{endian}IIIIIIIIII"
        sh_size = 40
        sym_fmt = f"{endian}IIIBBH"
        sym_size = 16

    print(
        f"ELF class={'64' if ei_class == 2 else '32'} "
        f"machine={EM_NAMES.get(e_machine, e_machine)} type={e_type} entry=0x{e_entry:x} bytes={len(data)}"
    )

    sections = []
    for i in range(e_shnum):
        off = e_shoff + i * sh_size
        if off + sh_size > len(data):
            break
        fields = struct.unpack_from(sh_fmt, data, off)
        sections.append(fields)

    shstr_bytes = b""
    if 0 <= e_shstrndx < len(sections):
        sh = sections[e_shstrndx]
        s_off, s_sz = sh[4], sh[5]
        shstr_bytes = data[s_off : s_off + s_sz]

    def read_cstr(blob: bytes, idx: int) -> str:
        if idx < 0 or idx >= len(blob):
            return ""
        end = blob.find(b"\x00", idx)
        if end < 0:
            end = len(blob)
        return blob[idx:end].decode("utf-8", errors="replace")

    print(f"\n[Sections: {len(sections)}]")
    jni_hits: list[str] = []
    for idx, sh in enumerate(sections):
        name = read_cstr(shstr_bytes, sh[0])
        sh_type, sh_addr, sh_off, sh_sz, sh_link = sh[1], sh[3], sh[4], sh[5], sh[6]
        if name:
            print(f"  [{idx:2d}] {name:<18s} addr=0x{sh_addr:<8x} off=0x{sh_off:<8x} size={sh_sz}")
        # SHT_SYMTAB(2) / SHT_DYNSYM(11)
        if sh_type in (2, 11) and 0 <= sh_link < len(sections):
            str_sec = sections[sh_link]
            str_blob = data[str_sec[4] : str_sec[4] + str_sec[5]]
            sec_blob = data[sh_off : sh_off + sh_sz]
            for j in range(0, len(sec_blob) - sym_size + 1, sym_size):
                if ei_class == 2:
                    st_name, _info, _other, _shndx, st_val, st_sz = struct.unpack_from(sym_fmt, sec_blob, j)
                else:
                    st_name, st_val, st_sz, _info, _other, _shndx = struct.unpack_from(sym_fmt, sec_blob, j)
                sname = read_cstr(str_blob, st_name)
                if sname == "JNI_OnLoad" or sname.startswith("Java_") or "RegisterNatives" in sname:
                    jni_hits.append(f"{sname} @ vaddr=0x{st_val:x} size={st_sz}")

    print("\n[JNI / RegisterNatives Symbols]")
    for h in sorted(set(jni_hits)):
        print(f"  {h}")
    if not jni_hits:
        print("  (none matched; inspect JNINativeMethod signatures in .rodata)")

    # Scan candidate JNI type signatures such as (Ljava/lang/String;)Ljava/lang/String;
    sig_pat = re.compile(rb"\([\[A-Za-z0-9_/;]*\)[VZBCSIJFDL\[][A-Za-z0-9_/;$]*")
    sigs = []
    for m in sig_pat.finditer(data):
        s = m.group(0).decode("ascii", errors="ignore")
        if 3 <= len(s) <= 120:
            sigs.append((m.start(), s))
        if len(sigs) >= 30:
            break
    if sigs:
        print(f"\n[JNI Signature Hints (first {len(sigs)})]")
        for off, s in sigs:
            print(f"  off=0x{off:x} {s}")


def main() -> int:
    ap = argparse.ArgumentParser(description="Inspect ELF sections, JNI symbols, and signature hints.")
    ap.add_argument("elf", type=Path, help="Path to .so or ELF binary")
    args = ap.parse_args()
    scan_elf(args.elf)
    return 0


if __name__ == "__main__":
    sys.exit(main())
