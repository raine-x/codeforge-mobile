---
name: elf-jni-reverse
display_name: ELF 与 JNI 原生库逆向与仿真
description: 安卓 .so 与 ARM64 ELF 逆向工作流：PT_LOAD 偏移换算、.rela.dyn 重定位、RegisterNatives 还原、ADRP 交叉引用与 Unicorn 一键仿真
triggers: reverse_analysis,逆向,elf,so,jni,JNI_OnLoad,RegisterNatives,unicorn,radare2,arm64
enabled: true
---

# ELF 与 JNI 原生库逆向与仿真

> 仅限本地授权样本；修改原二进制前须保留备份。

## 0. 防空转铁律（必读，严禁重复造轮子）
1. **严禁手写 `.rela.dyn` 重定位、`vaddr ↔ file_offset` 换算、`ADRP+ADD` / `ADRP+LDR` 扫描脚本** —— `elf_jni_scanner.py` 已内置完整重定位内存视图与交叉引用引擎（兼容无 Section Header 的脱节表加固 SO）。
2. **严禁人肉心算 ARM64 寄存器拼装/位移（如 `movk`、`ubfx`、`eor` 循环）或从零手搭 Unicorn 脚手架** —— 遇到运行时密钥生成函数或加解密函数，直接调用内置 `unicorn_arm64_harness.py` 一键跑出真实内存结果。
3. **临时脚本严禁命名为 `dis.py`、`code.py`、`token.py`、`types.py`**（会遮蔽 Python 标准库导致 `import capstone` / `import unicorn` 失败）。

## 1. 一键完成段表映射、重定位、RegisterNatives 还原与交叉引用
`elf_jni_scanner.py` 会在内存中自动应用 `.rela.dyn`（`R_AARCH64_RELATIVE` / `GLOB_DAT`）与 `.rela.plt`，直接读出重定位后的真实函数指针与字符串：
```bash
# 查看 PT_LOAD (vaddr <-> file_off 差值)、导出 JNI 符号，并自动从重定位内存还原 RegisterNatives (JNINativeMethod) 表
python3 .codeforge/skills/elf-jni-reverse/references/elf_jni_scanner.py libtarget.so

# 扫描全部可执行段的 ADRP+ADD / ADRP+LDR (含 GOT 间接引用) 与 BL 调用交叉引用
python3 .codeforge/skills/elf-jni-reverse/references/elf_jni_scanner.py libtarget.so --xref "" --limit 80
python3 .codeforge/skills/elf-jni-reverse/references/elf_jni_scanner.py libtarget.so --xref "RC4"

# 反汇编指定虚拟地址或 JNI 方法名（自动转换 vaddr->file_off，并在同行注释 ADRP 字符串、GOT 符号与 movk 位域）
python3 .codeforge/skills/elf-jni-reverse/references/elf_jni_scanner.py libtarget.so --disasm 0x1818 --len 80
```

## 2. Unicorn ARM64 一键函数与 JNI 仿真（免手搭环境）
`unicorn_arm64_harness.py` 已自动处理：**`PT_LOAD` 页对齐映射 + `.bss` 清零 + `.rela.dyn` 重定位 + 开启 `CPACR_EL1` SIMD/NEON + `TPIDR_EL0` Stack Canary + 常用 libc PLT Hook（`strlen`/`memcpy`/`memset`/`strcmp`/`malloc` 等）+ 完整 Fake `JNIEnv*`（`GetStringUTFChars`/`NewStringUTF`/`GetByteArrayElements` 等）**：
```bash
# 场景 A：运行密钥初始化函数 0x1178，随后直接 dump 全局缓冲区 0xc238 的真实内容
python3 .codeforge/skills/elf-jni-reverse/references/unicorn_arm64_harness.py libsec.so --call 0x1178 --dump 0xc238:64 --trace-calls

# 场景 B：先跑初始化函数 0x1178，再调用普通 C 函数 0x3470(data_ptr, len, key_ptr) 并 dump 输出缓冲
python3 .codeforge/skills/elf-jni-reverse/references/unicorn_arm64_harness.py libsec.so --init-call 0x1178 --call 0x3470 --arg file:cipher.bin --arg int:64 --arg str:mykey --dump x0:64

# 场景 C：以 JNI 方式调用 (自动传入 x0=JNIEnv*, x1=thiz)，参数自动封装为 jbyteArray / jstring，并读取返回的 jstring 或 jbyteArray
python3 .codeforge/skills/elf-jni-reverse/references/unicorn_arm64_harness.py libsec.so --init-call 0x1178 --jni-call 0x201c --arg int:0 --dump ret:jstring
python3 .codeforge/skills/elf-jni-reverse/references/unicorn_arm64_harness.py libsec.so --init-call 0x1178 --jni-call 0x1818 --arg file:page.js --arg str:key --dump ret:jbytearray
```
也可以在自定义 Python 脚本中直接 `from unicorn_arm64_harness import Arm64JniHarness` 复用实例做批量高速调用。

## 3. 原生函数二进制修补（需开启「允许修改与重打包」）
直接按虚拟地址 `vaddr` 修补 ARM64 函数返回值（脚本自动按 `PT_LOAD` 换算为文件偏移）：
```bash
# 将 vaddr=0x2198 处函数修补为 mov w0, #1; ret (返回 true)，可选 0 / 1 / nop
python3 .codeforge/skills/elf-jni-reverse/references/elf_jni_scanner.py libtarget.so --patch-ret 0x2198 --val 1 -o libtarget_patched.so
```
