---
name: elf-jni-reverse
display_name: ELF 与 JNI 原生库逆向分析
description: 安卓 .so 与 ELF 二进制静态只读分析流：ELF 头与节表、DT_NEEDED 依赖、JNI_OnLoad/Java_* 导出定位、RegisterNatives 特征与 radare2 反汇编
triggers: elf,so,jni,JNI_OnLoad,RegisterNatives,readelf,objdump,radare2
enabled: true
---

# ELF 与 JNI 原生库逆向分析

> 仅分析本地授权样本；静态侦察优先使用只读命令，不直接修改原二进制文件。

## 1. 基础文件与段表侦察
```bash
sha256sum libtarget.so
file libtarget.so
readelf -h -S -d libtarget.so
nm -D libtarget.so
```
- 重点关注 `EM_AARCH64` / `EM_ARM` / `EM_X86_64` 架构、`DT_NEEDED` 依赖（`liblog.so`、`libz.so`、`libc.so`）、节对齐及异常高熵加密段。

## 2. JNI 桥接与动态注册定位
运行内置零依赖 ELF/JNI 扫描脚本，提取 `JNI_OnLoad`、`Java_*` 符号、`JNINativeMethod` 常见特征字符串与交叉线索：
```bash
python3 .codeforge/skills/elf-jni-reverse/references/elf_jni_scanner.py libtarget.so
```
分析路径分两条：
1. **静态导出**：符号名符合 `Java_<包名>_<类名>_<方法名>`，直接取其虚拟地址后用 `objdump -d` 或 `r2` 反汇编。
2. **动态注册**：查找 `JNI_OnLoad` 地址 → 跟踪 `FindClass` / `RegisterNatives` 调用前传给 `x2`/`r2` 的 `JNINativeMethod` 结构体数组（`{namePtr, sigPtr, fnPtr}`，ARM64 下每项 24 字节）。

## 3. 反汇编与交叉引用
若环境已装 `逆向工具 (binutils/file/radare2)`：
```bash
objdump -d -j .text libtarget.so
r2 -AA -qc "afl; s sym.JNI_OnLoad; pdf" libtarget.so
strings -n 6 libtarget.so
```
- 若脚本或环境中装有 `capstone`（`py3-capstone`），可直接用 Python 按目标偏移精准反汇编指定字节窗口。

## 4. 证据核验要求
- 所有结论必须注明文件架构、函数符号或文件偏移/虚拟地址、关键常量与寄存器数据流；
- 反编译/反汇编推断须标注置信度，不把猜测当实锤。
