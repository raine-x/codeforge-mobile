#!/usr/bin/env python3
"""Pure-stdlib DEX Checksum Recalculator, Method Bytecode Patcher, Aligned APK Repacker & Signer.

Features:
1. `fix-dex`: Recalculates DEX SHA-1 signature (offset 0x0C..0x20) and Adler-32 checksum (0x08..0x0C)
2. `patch-return`: Patches a matched Dalvik method to return 0 (false), 1 (true), or void,
   and automatically recalculates DEX SHA-1 & Adler-32
3. `patch-hex`: Patches arbitrary file offset with hex bytes (auto-fixes DEX header if file is a DEX)
4. `repack`: Losslessly repacks an APK, replacing or removing specified entries, stripping old
   META-INF signatures, and enforcing Android 11+/15+ ZIP alignment:
   - `resources.arsc` stored uncompressed (ZIP_STORED) at 4-byte boundary
   - Uncompressed `lib/**/*.so` aligned to 4096-byte (or 16384-byte) boundary via ZIP extra field padding
5. `sign`: Signs an APK using `uber-apk-signer`, `apksigner`, or `jarsigner` (auto-creating a debug keystore)
"""

from __future__ import annotations

import argparse
import fnmatch
import hashlib
import shutil
import subprocess
import struct
import sys
import tempfile
import zipfile
import zlib
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import dex_inspector  # noqa: E402


def fix_dex_headers(dex_bytes: bytes) -> bytes:
    if len(dex_bytes) < 112 or not dex_bytes.startswith(b"dex\n"):
        raise ValueError("Buffer is not a valid DEX file")
    buf = bytearray(dex_bytes)
    # Update header file_size ONLY if no trailing packer payload is intentionally preserved;
    # checksum & signature in standard DEX cover [12:file_size] and [32:file_size].
    (hdr_file_size,) = struct.unpack_from("<I", buf, 32)
    check_end = hdr_file_size if 112 <= hdr_file_size <= len(buf) else len(buf)

    sha1_digest = hashlib.sha1(buf[32:check_end]).digest()
    buf[12:32] = sha1_digest
    adler = zlib.adler32(buf[12:check_end]) & 0xFFFFFFFF
    struct.pack_into("<I", buf, 8, adler)
    return bytes(buf)


def patch_dex_method_return(dex_bytes: bytes, method_pattern: str, ret_val: str) -> tuple[bytes, list[str]]:
    d = dex_inspector.DexFile("classes.dex", dex_bytes)
    q = method_pattern.lower()
    matched = [m for m in d.method_defs if q in m["full"].lower() and m["code_off"] > 0]
    if not matched:
        raise ValueError(f"No bytecode method matching '{method_pattern}' found")

    if ret_val == "0":
        patch_insns = bytes.fromhex("12000f00")  # const/4 v0, 0x0 ; return v0
    elif ret_val == "1":
        patch_insns = bytes.fromhex("12100f00")  # const/4 v0, 0x1 ; return v0
    elif ret_val == "void":
        patch_insns = bytes.fromhex("0e00")  # return-void
    else:
        raise ValueError(f"Unsupported ret_val: {ret_val}")

    buf = bytearray(dex_bytes)
    logs: list[str] = []
    for m in matched:
        code_off = m["code_off"]
        regs_sz, ins_sz, _outs_sz, _tries_sz, _dbg_off, insns_cnt = struct.unpack_from("<4HII", buf, code_off)
        if insns_cnt * 2 < len(patch_insns):
            raise ValueError(f"Method {m['full']} body too small ({insns_cnt * 2}B) for {len(patch_insns)}B patch")
        if ret_val in ("0", "1") and regs_sz == 0:
            struct.pack_into("<H", buf, code_off, max(1, ins_sz))
        insns_off = code_off + 16
        buf[insns_off : insns_off + len(patch_insns)] = patch_insns
        logs.append(f"Patched {m['full']} @ 0x{insns_off:x} -> return {ret_val}")

    return fix_dex_headers(bytes(buf)), logs


def is_signature_entry(name: str) -> bool:
    up = name.upper()
    if not up.startswith("META-INF/"):
        return False
    base = up.split("/")[-1]
    return (
        base == "MANIFEST.MF"
        or base.endswith((".SF", ".RSA", ".DSA", ".EC"))
        or base.startswith("SIG-")
    )


def repack_aligned_apk(
    in_apk: Path,
    out_apk: Path,
    replacements: dict[str, bytes] | None = None,
    remove_globs: list[str] | None = None,
    so_align: int = 4096,
) -> dict:
    replacements = replacements or {}
    remove_globs = remove_globs or []
    kept = 0
    replaced = 0
    removed = 0

    with zipfile.ZipFile(in_apk, "r") as zin, open(out_apk, "wb") as raw_out:
        with zipfile.ZipFile(raw_out, "w") as zout:
            seen: set[str] = set()
            for info in zin.infolist():
                name = info.filename
                if is_signature_entry(name):
                    removed += 1
                    continue
                if any(fnmatch.fnmatch(name, pat) for pat in remove_globs):
                    removed += 1
                    continue

                data = replacements[name] if name in replacements else zin.read(name)
                if name in replacements:
                    replaced += 1
                else:
                    kept += 1
                seen.add(name)

                new_info = zipfile.ZipInfo(filename=name, date_time=(2026, 1, 1, 0, 0, 0))
                new_info.external_attr = info.external_attr

                # Determine compression & alignment
                if name == "resources.arsc":
                    new_info.compress_type = zipfile.ZIP_STORED
                    align = 4
                elif name.startswith("lib/") and name.endswith(".so") and info.compress_type == zipfile.ZIP_STORED:
                    new_info.compress_type = zipfile.ZIP_STORED
                    align = so_align
                else:
                    new_info.compress_type = info.compress_type
                    align = 4 if new_info.compress_type == zipfile.ZIP_STORED else 0

                if align > 1:
                    cur_offset = raw_out.tell()
                    # Local file header is 30 bytes + len(filename) + len(extra)
                    name_bytes = name.encode("utf-8")
                    data_start_no_extra = cur_offset + 30 + len(name_bytes)
                    pad = (align - (data_start_no_extra % align)) % align
                    new_info.extra = b"\x00" * pad
                else:
                    new_info.extra = b""

                zout.writestr(new_info, data)

            for name, data in replacements.items():
                if name in seen:
                    continue
                replaced += 1
                new_info = zipfile.ZipInfo(filename=name, date_time=(2026, 1, 1, 0, 0, 0))
                new_info.compress_type = (
                    zipfile.ZIP_STORED if name == "resources.arsc" else zipfile.ZIP_DEFLATED
                )
                if name == "resources.arsc":
                    cur_offset = raw_out.tell()
                    data_start = cur_offset + 30 + len(name.encode("utf-8"))
                    pad = (4 - (data_start % 4)) % 4
                    new_info.extra = b"\x00" * pad
                zout.writestr(new_info, data)

    return {"kept": kept, "replaced": replaced, "removed": removed}


def verify_zip_alignment(apk_path: Path) -> list[tuple[str, int, int, bool]]:
    checks: list[tuple[str, int, int, bool]] = []
    raw = apk_path.read_bytes()
    with zipfile.ZipFile(apk_path, "r") as zf:
        for info in zf.infolist():
            if info.compress_type != zipfile.ZIP_STORED:
                continue
            hdr_off = info.header_offset
            fn_len, extra_len = struct.unpack_from("<HH", raw, hdr_off + 26)
            data_off = hdr_off + 30 + fn_len + extra_len
            if info.filename == "resources.arsc":
                checks.append((info.filename, data_off, 4, data_off % 4 == 0))
            elif info.filename.startswith("lib/") and info.filename.endswith(".so"):
                checks.append((info.filename, data_off, 4096, data_off % 4096 == 0))
    return checks


def ensure_debug_keystore(ks_path: Path) -> bool:
    if ks_path.is_file():
        return True
    keytool = shutil.which("keytool")
    if not keytool:
        return False
    ks_path.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        keytool,
        "-genkeypair",
        "-v",
        "-keystore",
        str(ks_path),
        "-alias",
        "androiddebugkey",
        "-keyalg",
        "RSA",
        "-keysize",
        "2048",
        "-validity",
        "10000",
        "-storepass",
        "android",
        "-keypass",
        "android",
        "-dname",
        "CN=Android Debug,O=Android,C=US",
    ]
    res = subprocess.run(cmd, capture_output=True, text=True)
    return res.returncode == 0 and ks_path.is_file()


def sign_apk(in_apk: Path, out_apk: Path) -> tuple[bool, str]:
    uber = shutil.which("uber-apk-signer")
    if uber:
        with tempfile.TemporaryDirectory() as tmp:
            res = subprocess.run(
                [uber, "-a", str(in_apk), "-o", tmp, "--allowResign"],
                capture_output=True,
                text=True,
            )
            signed_candidates = list(Path(tmp).glob("*.apk"))
            if res.returncode == 0 and signed_candidates:
                shutil.copyfile(signed_candidates[0], out_apk)
                return True, f"Signed with uber-apk-signer -> {out_apk}"

    ks = Path.home() / ".android" / "debug.keystore"
    if not ensure_debug_keystore(ks):
        ks = out_apk.parent / "cf_debug.keystore"
        ensure_debug_keystore(ks)

    apksigner = shutil.which("apksigner")
    if apksigner and ks.is_file():
        res = subprocess.run(
            [
                apksigner,
                "sign",
                "--ks",
                str(ks),
                "--ks-key-alias",
                "androiddebugkey",
                "--ks-pass",
                "pass:android",
                "--key-pass",
                "pass:android",
                "--out",
                str(out_apk),
                str(in_apk),
            ],
            capture_output=True,
            text=True,
        )
        if res.returncode == 0:
            return True, f"Signed with apksigner (v1+v2+v3) -> {out_apk}"

    jarsigner = shutil.which("jarsigner")
    if jarsigner and ks.is_file():
        if in_apk.resolve() != out_apk.resolve():
            shutil.copyfile(in_apk, out_apk)
        res = subprocess.run(
            [
                jarsigner,
                "-keystore",
                str(ks),
                "-storepass",
                "android",
                "-keypass",
                "android",
                str(out_apk),
                "androiddebugkey",
            ],
            capture_output=True,
            text=True,
        )
        if res.returncode == 0:
            return True, f"Signed with jarsigner (v1) -> {out_apk}"

    return False, "No signing tool found (install 'APK 逆向工具链' in Settings -> Environment Packages)"


def main() -> int:
    ap = argparse.ArgumentParser(description="DEX checksum fixer, bytecode patcher, aligned APK repacker & signer.")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p_fix = sub.add_parser("fix-dex", help="Recalculate DEX SHA-1 signature and Adler-32 checksum")
    p_fix.add_argument("dex", type=Path, help="Input .dex file")
    p_fix.add_argument("-o", "--output", type=Path, help="Output .dex file (defaults to in-place)")

    p_ret = sub.add_parser("patch-return", help="Patch Dalvik method return value (0, 1, or void) in .dex or .apk")
    p_ret.add_argument("target", type=Path, help="Input .dex or .apk")
    p_ret.add_argument("--method", required=True, help="Method substring pattern (e.g. 'VipManager->isVip')")
    p_ret.add_argument("--ret", choices=["0", "1", "void"], required=True, help="Return value to patch")
    p_ret.add_argument("-o", "--output", type=Path, required=True, help="Output .dex or .apk")
    p_ret.add_argument("--sign", action="store_true", help="Also sign output APK if target is an .apk")

    p_hex = sub.add_parser("patch-hex", help="Patch raw hex bytes at file offset (auto-updates DEX checksum)")
    p_hex.add_argument("target", type=Path, help="Input file (.dex, .so, etc.)")
    p_hex.add_argument("--offset", required=True, help="File offset (e.g. 0x1234)")
    p_hex.add_argument("--hex", required=True, help="Hex string to write (e.g. '12100f00')")
    p_hex.add_argument("-o", "--output", type=Path, help="Output file (defaults to in-place)")

    p_rep = sub.add_parser("repack", help="Losslessly repack APK with 4B/4KB/16KB alignment")
    p_rep.add_argument("apk", type=Path, help="Input .apk")
    p_rep.add_argument("-o", "--output", type=Path, required=True, help="Output .apk")
    p_rep.add_argument("--replace", action="append", default=[], metavar="ENTRY=PATH", help="Replace archive entry with local file")
    p_rep.add_argument("--remove", action="append", default=[], metavar="GLOB", help="Remove archive entries matching glob")
    p_rep.add_argument("--page-align", type=int, default=4096, choices=[4096, 16384], help="Alignment for uncompressed .so (default: 4096)")
    p_rep.add_argument("--sign", action="store_true", help="Auto-sign the repacked APK")

    p_sgn = sub.add_parser("sign", help="Sign an APK and verify alignment")
    p_sgn.add_argument("apk", type=Path, help="Input unsigned .apk")
    p_sgn.add_argument("-o", "--output", type=Path, required=True, help="Output signed .apk")

    args = ap.parse_args()

    if args.cmd == "fix-dex":
        out = args.output or args.dex
        fixed = fix_dex_headers(args.dex.read_bytes())
        out.write_bytes(fixed)
        adler = struct.unpack_from("<I", fixed, 8)[0]
        print(f"Fixed DEX headers: adler32=0x{adler:08x} sha1={fixed[12:32].hex()} -> {out}")
        return 0

    if args.cmd == "patch-hex":
        out = args.output or args.target
        off = int(args.offset, 0)
        patch_b = bytes.fromhex(args.hex.replace(" ", ""))
        buf = bytearray(args.target.read_bytes())
        if off < 0 or off + len(patch_b) > len(buf):
            print(f"Offset 0x{off:x} + {len(patch_b)}B out of bounds ({len(buf)}B)", file=sys.stderr)
            return 1
        old_b = bytes(buf[off : off + len(patch_b)])
        buf[off : off + len(patch_b)] = patch_b
        final_b = fix_dex_headers(bytes(buf)) if buf.startswith(b"dex\n") else bytes(buf)
        out.write_bytes(final_b)
        print(f"Patched 0x{off:x}: {old_b.hex()} -> {patch_b.hex()} ({out})")
        return 0

    if args.cmd == "patch-return":
        if zipfile.is_zipfile(args.target):
            replacements: dict[str, bytes] = {}
            with zipfile.ZipFile(args.target, "r") as zf:
                for n in sorted(x for x in zf.namelist() if x.endswith(".dex") and "/" not in x):
                    try:
                        patched_dex, logs = patch_dex_method_return(zf.read(n), args.method, args.ret)
                        replacements[n] = patched_dex
                        for l in logs:
                            print(f"[{n}] {l}")
                    except ValueError:
                        continue
            if not replacements:
                print(f"No method matching '{args.method}' found in any classes*.dex", file=sys.stderr)
                return 1
            tmp_out = args.output.with_suffix(".unsigned.apk") if args.sign else args.output
            stats = repack_aligned_apk(args.target, tmp_out, replacements=replacements)
            print(f"Repacked APK: {stats}")
            if args.sign:
                ok, msg = sign_apk(tmp_out, args.output)
                tmp_out.unlink(missing_ok=True)
                print(msg)
                return 0 if ok else 1
            return 0
        else:
            patched_dex, logs = patch_dex_method_return(args.target.read_bytes(), args.method, args.ret)
            for l in logs:
                print(l)
            args.output.write_bytes(patched_dex)
            print(f"Saved patched DEX -> {args.output}")
            return 0

    if args.cmd == "repack":
        repl_map: dict[str, bytes] = {}
        for item in args.replace:
            if "=" not in item:
                print(f"Invalid --replace '{item}', expected ENTRY=PATH", file=sys.stderr)
                return 1
            entry_name, local_p = item.split("=", 1)
            repl_map[entry_name] = Path(local_p).read_bytes()
        tmp_out = args.output.with_suffix(".unsigned.apk") if args.sign else args.output
        stats = repack_aligned_apk(
            args.apk,
            tmp_out,
            replacements=repl_map,
            remove_globs=args.remove,
            so_align=args.page_align,
        )
        checks = verify_zip_alignment(tmp_out)
        print(f"Repacked APK ({stats}): {tmp_out}")
        for fn, off, req, ok in checks:
            print(f"  [Align {req}B] {fn}: data_off=0x{off:x} ok={ok}")
        if args.sign:
            ok, msg = sign_apk(tmp_out, args.output)
            tmp_out.unlink(missing_ok=True)
            print(msg)
            return 0 if ok else 1
        return 0

    if args.cmd == "sign":
        ok, msg = sign_apk(args.apk, args.output)
        print(msg)
        return 0 if ok else 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
