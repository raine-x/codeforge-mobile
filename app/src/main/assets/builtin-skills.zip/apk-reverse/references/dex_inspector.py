#!/usr/bin/env python3
"""Pure-stdlib DEX header, class/method index, and string search inspector."""

from __future__ import annotations

import argparse
import struct
import sys
from pathlib import Path


def read_uleb128(buf: bytes, pos: int) -> tuple[int, int]:
    val = 0
    shift = 0
    while pos < len(buf) and shift < 35:
        b = buf[pos]
        pos += 1
        val |= (b & 0x7F) << shift
        if (b & 0x80) == 0:
            break
        shift += 7
    return val, pos


def read_mutf8_string(buf: bytes, data_off: int) -> str:
    if data_off <= 0 or data_off >= len(buf):
        return ""
    _, p = read_uleb128(buf, data_off)
    end = buf.find(b"\x00", p)
    if end < 0:
        return ""
    return buf[p:end].decode("utf-8", errors="replace")


def parse_dex(path: Path) -> dict:
    data = path.read_bytes()
    if len(data) < 112 or not data.startswith(b"dex\n"):
        raise ValueError(f"Not a valid DEX file: {path}")

    magic_ver = data[4:8].rstrip(b"\x00\n").decode("ascii", errors="replace")
    (
        file_size,
        header_size,
        endian_tag,
        _link_size,
        _link_off,
        _map_off,
        str_cnt,
        str_off,
        type_cnt,
        type_off,
        proto_cnt,
        _proto_off,
        field_cnt,
        _field_off,
        method_cnt,
        method_off,
        class_cnt,
        class_off,
    ) = struct.unpack_from("<18I", data, 32)

    strings: list[str] = []
    for i in range(str_cnt):
        pos = str_off + i * 4
        if pos + 4 > len(data):
            break
        (s_off,) = struct.unpack_from("<I", data, pos)
        strings.append(read_mutf8_string(data, s_off))

    def get_type(idx: int) -> str:
        pos = type_off + idx * 4
        if idx < 0 or idx >= type_cnt or pos + 4 > len(data):
            return f"type#{idx}"
        (desc_idx,) = struct.unpack_from("<I", data, pos)
        return strings[desc_idx] if 0 <= desc_idx < len(strings) else f"str#{desc_idx}"

    classes: list[dict] = []
    for i in range(class_cnt):
        pos = class_off + i * 32
        if pos + 32 > len(data):
            break
        cls_idx, acc, super_idx, _, _, _, _, _ = struct.unpack_from("<8I", data, pos)
        classes.append(
            {
                "name": get_type(cls_idx),
                "access": acc,
                "super": "" if super_idx == 0xFFFFFFFF else get_type(super_idx),
            }
        )

    methods: list[str] = []
    for i in range(min(method_cnt, 50000)):
        pos = method_off + i * 8
        if pos + 8 > len(data):
            break
        cls_idx, _proto_idx, name_idx = struct.unpack_from("<HHI", data, pos)
        m_name = strings[name_idx] if 0 <= name_idx < len(strings) else f"str#{name_idx}"
        methods.append(f"{get_type(cls_idx)}->{m_name}")

    return {
        "version": magic_ver,
        "file_size": file_size,
        "header_size": header_size,
        "endian_tag": endian_tag,
        "counts": {
            "strings": str_cnt,
            "types": type_cnt,
            "protos": proto_cnt,
            "fields": field_cnt,
            "methods": method_cnt,
            "classes": class_cnt,
        },
        "strings": strings,
        "classes": classes,
        "methods": methods,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Inspect Dalvik DEX metadata, classes, and strings.")
    ap.add_argument("dex", type=Path, help="Path to classes*.dex")
    ap.add_argument("--filter", default="", help="Case-insensitive substring filter for classes/methods")
    ap.add_argument("--strings", default="", help="Search strings containing substring")
    ap.add_argument("--limit", type=int, default=40, help="Max rows to print (default: 40)")
    args = ap.parse_args()

    info = parse_dex(args.dex)
    cnt = info["counts"]
    print(
        f"DEX v{info['version']} size={info['file_size']}B "
        f"strings={cnt['strings']} types={cnt['types']} methods={cnt['methods']} classes={cnt['classes']}"
    )

    flt = args.filter.lower()
    if flt or not args.strings:
        matched_cls = [c["name"] for c in info["classes"] if not flt or flt in c["name"].lower()]
        print(f"\n[Classes: {len(matched_cls)} matched]")
        for name in matched_cls[: args.limit]:
            print(f"  {name}")

        if flt:
            matched_m = [m for m in info["methods"] if flt in m.lower()]
            print(f"\n[Methods: {len(matched_m)} matched]")
            for m in matched_m[: args.limit]:
                print(f"  {m}")

    if args.strings:
        q = args.strings.lower()
        hits = [(idx, s) for idx, s in enumerate(info["strings"]) if q in s.lower()]
        print(f"\n[Strings matching {args.strings!r}: {len(hits)}]")
        for idx, s in hits[: args.limit]:
            print(f"  [{idx}] {s[:160]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
