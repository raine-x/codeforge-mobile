#!/usr/bin/env python3
"""Pure-stdlib Multi-DEX & APK Inspector, Trailing Payload Detector, Dalvik Disassembler & Xref Engine.

Capabilities:
- Accepts either a .dex file or an .apk archive (automatically iterates all classes*.dex)
- Detects hidden/encrypted payloads appended after DEX header.file_size (e.g. 360 jiagu tail blobs)
- Parses strings, types, prototypes, fields, methods, class_data_item, and code_item
- Lists all JNI `native` methods (--native)
- Disassembles Dalvik bytecode methods (--disasm <pattern>) with exact file offsets and resolved symbols
- Finds cross-references (--xref <query>) to strings, methods, fields, or types across all methods
"""

from __future__ import annotations

import argparse
import math
import struct
import sys
import zipfile
from collections import Counter
from pathlib import Path

ACC_FLAGS = [
    (0x0001, "PUBLIC"),
    (0x0002, "PRIVATE"),
    (0x0004, "PROTECTED"),
    (0x0008, "STATIC"),
    (0x0010, "FINAL"),
    (0x0020, "SYNCHRONIZED"),
    (0x0100, "NATIVE"),
    (0x0200, "INTERFACE"),
    (0x0400, "ABSTRACT"),
    (0x1000, "SYNTHETIC"),
    (0x10000, "CONSTRUCTOR"),
]


def format_access(acc: int) -> str:
    names = [name for bit, name in ACC_FLAGS if acc & bit]
    return " ".join(names)


def shannon_entropy(chunk: bytes) -> float:
    if not chunk:
        return 0.0
    n = len(chunk)
    counts = Counter(chunk)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())


def read_uleb128(buf: bytes, pos: int) -> tuple[int, int]:
    val = 0
    shift = 0
    while pos < len(buf) and shift < 35:
        b = buf[pos]
        pos += 1
        val |= (b & 0x7F) << shift
        if (b & 0x80) == 0:
            break
        shift += 7
    return val, pos


def read_mutf8_string(buf: bytes, data_off: int) -> str:
    if data_off <= 0 or data_off >= len(buf):
        return ""
    _, p = read_uleb128(buf, data_off)
    end = buf.find(b"\x00", p)
    if end < 0:
        return ""
    return buf[p:end].decode("utf-8", errors="replace")


class DexFile:
    def __init__(self, name: str, data: bytes) -> None:
        self.name = name
        self.data = data
        if len(data) < 112 or not data.startswith(b"dex\n"):
            raise ValueError(f"Not a valid DEX file: {name}")

        self.version = data[4:8].rstrip(b"\x00\n").decode("ascii", errors="replace")
        (
            self.file_size,
            self.header_size,
            self.endian_tag,
            _link_size,
            _link_off,
            _map_off,
            self.str_cnt,
            self.str_off,
            self.type_cnt,
            self.type_off,
            self.proto_cnt,
            self.proto_off,
            self.field_cnt,
            self.field_off,
            self.method_cnt,
            self.method_off,
            self.class_cnt,
            self.class_off,
        ) = struct.unpack_from("<18I", data, 32)

        self.strings: list[str] = []
        for i in range(self.str_cnt):
            pos = self.str_off + i * 4
            if pos + 4 > len(data):
                break
            (s_off,) = struct.unpack_from("<I", data, pos)
            self.strings.append(read_mutf8_string(data, s_off))

        self.types: list[str] = []
        for i in range(self.type_cnt):
            pos = self.type_off + i * 4
            if pos + 4 > len(data):
                break
            (desc_idx,) = struct.unpack_from("<I", data, pos)
            self.types.append(self.get_str(desc_idx))

        self.protos: list[str] = []
        for i in range(self.proto_cnt):
            pos = self.proto_off + i * 12
            if pos + 12 > len(data):
                break
            _shorty_idx, ret_idx, params_off = struct.unpack_from("<3I", data, pos)
            ret_t = self.get_type(ret_idx)
            params: list[str] = []
            if 0 < params_off < len(data) - 4:
                (p_cnt,) = struct.unpack_from("<I", data, params_off)
                for j in range(min(p_cnt, 256)):
                    t_pos = params_off + 4 + j * 2
                    if t_pos + 2 > len(data):
                        break
                    (t_idx,) = struct.unpack_from("<H", data, t_pos)
                    params.append(self.get_type(t_idx))
            self.protos.append(f"({''.join(params)}){ret_t}")

        self.fields: list[str] = []
        for i in range(self.field_cnt):
            pos = self.field_off + i * 8
            if pos + 8 > len(data):
                break
            cls_idx, type_idx, name_idx = struct.unpack_from("<HHI", data, pos)
            self.fields.append(f"{self.get_type(cls_idx)}->{self.get_str(name_idx)}:{self.get_type(type_idx)}")

        self.methods: list[str] = []
        for i in range(self.method_cnt):
            pos = self.method_off + i * 8
            if pos + 8 > len(data):
                break
            cls_idx, proto_idx, name_idx = struct.unpack_from("<HHI", data, pos)
            proto_s = self.protos[proto_idx] if 0 <= proto_idx < len(self.protos) else ""
            self.methods.append(f"{self.get_type(cls_idx)}->{self.get_str(name_idx)}{proto_s}")

        self.classes: list[dict] = []
        self.method_defs: list[dict] = []
        self._parse_classes()

    def get_str(self, idx: int) -> str:
        return self.strings[idx] if 0 <= idx < len(self.strings) else f"str#{idx}"

    def get_type(self, idx: int) -> str:
        return self.types[idx] if 0 <= idx < len(self.types) else f"type#{idx}"

    def get_field(self, idx: int) -> str:
        return self.fields[idx] if 0 <= idx < len(self.fields) else f"field#{idx}"

    def get_method(self, idx: int) -> str:
        return self.methods[idx] if 0 <= idx < len(self.methods) else f"method#{idx}"

    def _parse_classes(self) -> None:
        data = self.data
        for i in range(self.class_cnt):
            pos = self.class_off + i * 32
            if pos + 32 > len(data):
                break
            cls_idx, acc, super_idx, _if_off, src_idx, _ann_off, class_data_off, _static_off = (
                struct.unpack_from("<8I", data, pos)
            )
            cls_name = self.get_type(cls_idx)
            cls_info = {
                "name": cls_name,
                "access": acc,
                "super": "" if super_idx == 0xFFFFFFFF else self.get_type(super_idx),
                "source": "" if src_idx == 0xFFFFFFFF else self.get_str(src_idx),
            }
            self.classes.append(cls_info)

            if class_data_off == 0 or class_data_off >= len(data):
                continue
            p = class_data_off
            sf_cnt, p = read_uleb128(data, p)
            if_cnt, p = read_uleb128(data, p)
            dm_cnt, p = read_uleb128(data, p)
            vm_cnt, p = read_uleb128(data, p)

            for _ in range(sf_cnt + if_cnt):
                _f_diff, p = read_uleb128(data, p)
                _f_acc, p = read_uleb128(data, p)

            for m_total in (dm_cnt, vm_cnt):
                m_idx = 0
                for _ in range(m_total):
                    m_diff, p = read_uleb128(data, p)
                    m_acc, p = read_uleb128(data, p)
                    code_off, p = read_uleb128(data, p)
                    m_idx += m_diff
                    full_sig = self.get_method(m_idx)
                    self.method_defs.append(
                        {
                            "dex": self.name,
                            "class": cls_name,
                            "method_idx": m_idx,
                            "full": full_sig,
                            "access": m_acc,
                            "code_off": code_off,
                        }
                    )


def decode_dalvik_insns(dex: DexFile, code_off: int) -> tuple[dict, list[dict]]:
    data = dex.data
    if code_off <= 0 or code_off + 16 > len(data):
        return {}, []
    regs_sz, ins_sz, outs_sz, tries_sz, debug_off, insns_cnt = struct.unpack_from("<4HII", data, code_off)
    meta = {
        "registers": regs_sz,
        "ins": ins_sz,
        "outs": outs_sz,
        "tries": tries_sz,
        "debug_off": debug_off,
        "insns_units": insns_cnt,
        "insns_file_off": code_off + 16,
    }
    insns_base = code_off + 16
    end_off = min(len(data), insns_base + insns_cnt * 2)
    pos = insns_base
    out: list[dict] = []

    while pos + 2 <= end_off:
        file_off = pos
        rel_unit = (pos - insns_base) // 2
        (u0,) = struct.unpack_from("<H", data, pos)
        op = u0 & 0xFF
        hi = (u0 >> 8) & 0xFF

        # Variable-length payload pseudo-instructions (packed-switch / sparse-switch / fill-array-data)
        if u0 == 0x0100 and pos + 4 <= end_off:
            (sz,) = struct.unpack_from("<H", data, pos + 2)
            step = (sz * 2 + 4) * 2
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + step], "text": f"packed-switch-payload ({sz} entries)", "ref": ""})
            pos += max(2, step)
            continue
        if u0 == 0x0200 and pos + 4 <= end_off:
            (sz,) = struct.unpack_from("<H", data, pos + 2)
            step = (sz * 4 + 2) * 2
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + step], "text": f"sparse-switch-payload ({sz} entries)", "ref": ""})
            pos += max(2, step)
            continue
        if u0 == 0x0300 and pos + 8 <= end_off:
            elem_w, elem_cnt = struct.unpack_from("<HI", data, pos + 2)
            total_bytes = elem_w * elem_cnt
            step = 8 + ((total_bytes + 1) & ~1)
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + step], "text": f"fill-array-data-payload ({elem_cnt}x{elem_w}B)", "ref": ""})
            pos += max(2, step)
            continue

        # 10x / 11x / 12x (2 bytes)
        if op == 0x00:
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + 2], "text": "nop", "ref": ""})
            pos += 2
        elif op == 0x0E:
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + 2], "text": "return-void", "ref": ""})
            pos += 2
        elif op in (0x0F, 0x10, 0x11):
            mn = {0x0F: "return", 0x10: "return-wide", 0x11: "return-object"}[op]
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + 2], "text": f"{mn} v{hi}", "ref": ""})
            pos += 2
        elif op == 0x12:
            v_a = hi & 0xF
            lit = (hi >> 4) & 0xF
            if lit >= 8:
                lit -= 16
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + 2], "text": f"const/4 v{v_a}, #{lit}", "ref": ""})
            pos += 2
        elif op in (0x01, 0x04, 0x07):
            mn = {0x01: "move", 0x04: "move-wide", 0x07: "move-object"}[op]
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + 2], "text": f"{mn} v{hi & 0xF}, v{(hi >> 4) & 0xF}", "ref": ""})
            pos += 2
        elif op in (0x0A, 0x0B, 0x0C, 0x0D):
            mn = {0x0A: "move-result", 0x0B: "move-result-wide", 0x0C: "move-result-object", 0x0D: "move-exception"}[op]
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + 2], "text": f"{mn} v{hi}", "ref": ""})
            pos += 2
        elif op == 0x28:
            off8 = hi - 256 if hi >= 128 else hi
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + 2], "text": f"goto +0x{rel_unit + off8:04x}", "ref": ""})
            pos += 2

        # 21s / 21h / 21c / 22c / 21t / 22t / 20t (4 bytes)
        elif op in (0x13, 0x15, 0x16, 0x19) and pos + 4 <= end_off:
            (imm16,) = struct.unpack_from("<h", data, pos + 2)
            mn = {0x13: "const/16", 0x15: "const/high16", 0x16: "const-wide/16", 0x19: "const-wide/high16"}[op]
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + 4], "text": f"{mn} v{hi}, #{imm16}", "ref": ""})
            pos += 4
        elif op == 0x1A and pos + 4 <= end_off:
            (s_idx,) = struct.unpack_from("<H", data, pos + 2)
            s_val = dex.get_str(s_idx)
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + 4], "text": f'const-string v{hi}, {s_val!r}', "ref": s_val})
            pos += 4
        elif op == 0x1B and pos + 6 <= end_off:
            (s_idx,) = struct.unpack_from("<I", data, pos + 2)
            s_val = dex.get_str(s_idx)
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + 6], "text": f'const-string/jumbo v{hi}, {s_val!r}', "ref": s_val})
            pos += 6
        elif op in (0x1C, 0x1F, 0x22) and pos + 4 <= end_off:
            (t_idx,) = struct.unpack_from("<H", data, pos + 2)
            t_val = dex.get_type(t_idx)
            mn = {0x1C: "const-class", 0x1F: "check-cast", 0x22: "new-instance"}[op]
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + 4], "text": f"{mn} v{hi}, {t_val}", "ref": t_val})
            pos += 4
        elif 0x52 <= op <= 0x5F and pos + 4 <= end_off:
            (f_idx,) = struct.unpack_from("<H", data, pos + 2)
            f_val = dex.get_field(f_idx)
            mn = "iget" if op <= 0x58 else "iput"
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + 4], "text": f"{mn} v{hi & 0xF}, v{(hi >> 4) & 0xF}, {f_val}", "ref": f_val})
            pos += 4
        elif 0x60 <= op <= 0x6D and pos + 4 <= end_off:
            (f_idx,) = struct.unpack_from("<H", data, pos + 2)
            f_val = dex.get_field(f_idx)
            mn = "sget" if op <= 0x66 else "sput"
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + 4], "text": f"{mn} v{hi}, {f_val}", "ref": f_val})
            pos += 4
        elif 0x6E <= op <= 0x72 and pos + 6 <= end_off:
            (m_idx, reg_word) = struct.unpack_from("<HH", data, pos + 2)
            m_val = dex.get_method(m_idx)
            mn = {0x6E: "invoke-virtual", 0x6F: "invoke-super", 0x70: "invoke-direct", 0x71: "invoke-static", 0x72: "invoke-interface"}[op]
            argc = (hi >> 4) & 0xF
            regs = [reg_word & 0xF, (reg_word >> 4) & 0xF, (reg_word >> 8) & 0xF, (reg_word >> 12) & 0xF, hi & 0xF][:argc]
            reg_str = ", ".join(f"v{r}" for r in regs)
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + 6], "text": f"{mn} {{{reg_str}}}, {m_val}", "ref": m_val})
            pos += 6
        elif 0x74 <= op <= 0x78 and pos + 6 <= end_off:
            (m_idx, first_reg) = struct.unpack_from("<HH", data, pos + 2)
            m_val = dex.get_method(m_idx)
            mn = {0x74: "invoke-virtual/range", 0x75: "invoke-super/range", 0x76: "invoke-direct/range", 0x77: "invoke-static/range", 0x78: "invoke-interface/range"}[op]
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + 6], "text": f"{mn} {{v{first_reg}..v{first_reg + hi - 1}}}, {m_val}", "ref": m_val})
            pos += 6
        elif 0x32 <= op <= 0x37 and pos + 4 <= end_off:
            (rel16,) = struct.unpack_from("<h", data, pos + 2)
            mn = {0x32: "if-eq", 0x33: "if-ne", 0x34: "if-lt", 0x35: "if-ge", 0x36: "if-gt", 0x37: "if-le"}[op]
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + 4], "text": f"{mn} v{hi & 0xF}, v{(hi >> 4) & 0xF}, +0x{rel_unit + rel16:04x}", "ref": ""})
            pos += 4
        elif 0x38 <= op <= 0x3D and pos + 4 <= end_off:
            (rel16,) = struct.unpack_from("<h", data, pos + 2)
            mn = {0x38: "if-eqz", 0x39: "if-nez", 0x3A: "if-ltz", 0x3B: "if-gez", 0x3C: "if-gtz", 0x3D: "if-lez"}[op]
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + 4], "text": f"{mn} v{hi}, +0x{rel_unit + rel16:04x}", "ref": ""})
            pos += 4
        elif op in (0x14, 0x17) and pos + 6 <= end_off:
            (imm32,) = struct.unpack_from("<i", data, pos + 2)
            mn = "const" if op == 0x14 else "const-wide/32"
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + 6], "text": f"{mn} v{hi}, #0x{imm32 & 0xFFFFFFFF:x}", "ref": ""})
            pos += 6
        elif op == 0x18 and pos + 10 <= end_off:
            (imm64,) = struct.unpack_from("<Q", data, pos + 2)
            out.append({"file_off": file_off, "unit": rel_unit, "raw": data[pos : pos + 10], "text": f"const-wide v{hi}, #0x{imm64:x}", "ref": ""})
            pos += 10
        else:
            # Generic width fallback table for remaining Dalvik opcodes
            width = 2
            if op in (0x02, 0x05, 0x08, 0x20, 0x23, 0x29) or (0x2D <= op <= 0x31) or (0x44 <= op <= 0x51) or (0x90 <= op <= 0xAF) or (0xD0 <= op <= 0xE2):
                width = 4
            elif op in (0x03, 0x06, 0x09, 0x24, 0x25, 0x26, 0x2A, 0x2B, 0x2C):
                width = 6
            step = min(width, end_off - pos)
            raw_b = data[pos : pos + step]
            out.append({"file_off": file_off, "unit": rel_unit, "raw": raw_b, "text": f"op_0x{op:02x} ({raw_b.hex()})", "ref": ""})
            pos += max(2, step)

    return meta, out


def load_dex_targets(path: Path) -> list[DexFile]:
    if zipfile.is_zipfile(path):
        dex_list: list[DexFile] = []
        with zipfile.ZipFile(path, "r") as zf:
            names = sorted(
                (n for n in zf.namelist() if n.endswith(".dex") and "/" not in n),
                key=lambda x: (0 if x == "classes.dex" else int("".join(filter(str.isdigit, x)) or 999), x),
            )
            for n in names:
                dex_list.append(DexFile(n, zf.read(n)))
        return dex_list
    return [DexFile(path.name, path.read_bytes())]


def main() -> int:
    ap = argparse.ArgumentParser(description="Inspect DEX/APK metadata, classes, native methods, Dalvik bytecode, and xrefs.")
    ap.add_argument("dex", type=Path, help="Path to .dex or .apk")
    ap.add_argument("--filter", default="", help="Case-insensitive substring filter for classes/methods")
    ap.add_argument("--strings", default="", help="Search strings containing substring")
    ap.add_argument("--native", action="store_true", help="List all JNI native methods across DEX files")
    ap.add_argument("--disasm", default="", metavar="PATTERN", help="Disassemble methods matching class/method substring")
    ap.add_argument("--xref", default="", metavar="QUERY", help="Find methods referencing string/method/field/type substring")
    ap.add_argument("--extract-tail", type=Path, help="Extract hidden payload appended after DEX header.file_size")
    ap.add_argument("--limit", type=int, default=40, help="Max rows to print (default: 40)")
    args = ap.parse_args()

    dex_files = load_dex_targets(args.dex)
    print(
        "[Toolkit] Also in apk-reverse/references/: axml_arsc_parser.py (--summary/--xml/--arsc-strings), "
        "apk_sig_cert.py (v1/v2/v3 certs, toCharsString MD5, ASN.1/PKCS#7), apk_patch_repack.py (patch-return/repack/sign)"
    )

    for info in dex_files:
        actual_len = len(info.data)
        print(
            f"[{info.name}] DEX v{info.version} header_size={info.file_size}B actual={actual_len}B "
            f"strings={info.str_cnt} types={info.type_cnt} methods={info.method_cnt} classes={info.class_cnt}"
        )
        if actual_len > info.file_size:
            tail = info.data[info.file_size :]
            ent = shannon_entropy(tail[:65536])
            print(
                f"  [!] TRAILING PAYLOAD DETECTED in {info.name}: offset=0x{info.file_size:x} "
                f"length={len(tail)}B entropy={ent:.3f} head={tail[:24].hex()}"
            )
            if args.extract_tail:
                args.extract_tail.write_bytes(tail)
                print(f"  [+] Saved trailing payload -> {args.extract_tail}")

    if args.native:
        natives = [m for d in dex_files for m in d.method_defs if m["access"] & 0x0100]
        print(f"\n[JNI Native Methods: {len(natives)} total]")
        for m in natives[: args.limit]:
            print(f"  [{m['dex']}] {m['full']} ({format_access(m['access'])})")

    if args.xref:
        q = args.xref.lower()
        hits: list[str] = []
        for d in dex_files:
            for m in d.method_defs:
                if m["code_off"] <= 0:
                    continue
                _meta, insns = decode_dalvik_insns(d, m["code_off"])
                for ins in insns:
                    if ins["ref"] and q in ins["ref"].lower():
                        hits.append(
                            f"  [{d.name}] {m['full']} @ +0x{ins['unit']:04x} (file_off=0x{ins['file_off']:x}): {ins['text']}"
                        )
                        if len(hits) >= args.limit:
                            break
                if len(hits) >= args.limit:
                    break
        print(f"\n[Xref '{args.xref}': {len(hits)} hits shown]")
        for h in hits:
            print(h)

    if args.disasm:
        q = args.disasm.lower()
        matched_defs = [m for d in dex_files for m in d.method_defs if q in m["full"].lower()]
        print(f"\n[Disassembly '{args.disasm}': {len(matched_defs)} methods matched]")
        for m in matched_defs[: max(1, min(args.limit, 10))]:
            d = next(x for x in dex_files if x.name == m["dex"])
            print(f"\n--- [{d.name}] {m['full']} [{format_access(m['access'])}] code_off=0x{m['code_off']:x} ---")
            if m["code_off"] <= 0:
                print("  (no bytecode body: native or abstract)")
                continue
            meta, insns = decode_dalvik_insns(d, m["code_off"])
            print(
                f"  registers={meta['registers']} ins={meta['ins']} outs={meta['outs']} "
                f"insns_file_off=0x{meta['insns_file_off']:x} units={meta['insns_units']}"
            )
            for ins in insns[: args.limit * 3]:
                print(f"  0x{ins['file_off']:06x} (+0x{ins['unit']:04x}): {ins['raw'].hex():<12} {ins['text']}")

    flt = args.filter.lower()
    if flt or (not args.strings and not args.native and not args.disasm and not args.xref):
        matched_cls = [
            f"[{d.name}] {c['name']}" if len(dex_files) > 1 else c["name"]
            for d in dex_files
            for c in d.classes
            if not flt or flt in c["name"].lower()
        ]
        print(f"\n[Classes: {len(matched_cls)} matched]")
        for name in matched_cls[: args.limit]:
            print(f"  {name}")

        if flt:
            matched_m = [
                f"[{d.name}] {m}" if len(dex_files) > 1 else m
                for d in dex_files
                for m in d.methods
                if flt in m.lower()
            ]
            print(f"\n[Methods: {len(matched_m)} matched]")
            for m in matched_m[: args.limit]:
                print(f"  {m}")

    if args.strings:
        q = args.strings.lower()
        hits_s = [
            (d.name, idx, s)
            for d in dex_files
            for idx, s in enumerate(d.strings)
            if q in s.lower()
        ]
        print(f"\n[Strings matching '{args.strings}': {len(hits_s)} matched]")
        for dname, idx, s in hits_s[: args.limit]:
            pfx = f"[{dname}] " if len(dex_files) > 1 else ""
            print(f"  {pfx}[{idx}] {s!r}")

    return 0


if __name__ == "__main__":
    sys.exit(main())
