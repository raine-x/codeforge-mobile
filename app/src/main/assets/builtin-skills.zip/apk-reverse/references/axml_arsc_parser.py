#!/usr/bin/env python3
"""Pure-stdlib Android Binary XML (AXML) & resources.arsc parser and binary patcher.

Supports:
- Reading binary AndroidManifest.xml directly or inside an .apk archive
- Reconstructing human-readable XML (--xml)
- Structured security & reverse-engineering summary (--summary):
  package, versionCode/Name, min/targetSdk, Application class, packer detection,
  debuggable flag, exported Activities/Services/Receivers/Providers, schemes,
  and ad/update SDK component identification
- Parsing resources.arsc string pools (--arsc-strings), including non-standard
  UTF-16 endianness recovery
- In-place binary AXML patching without apktool (--set-debuggable, --replace-string)
"""

from __future__ import annotations

import argparse
import struct
import sys
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

RES_STRING_POOL_TYPE = 0x0001
RES_TABLE_TYPE = 0x0002
RES_XML_TYPE = 0x0003
RES_XML_START_NAMESPACE_TYPE = 0x0100
RES_XML_END_NAMESPACE_TYPE = 0x0101
RES_XML_START_ELEMENT_TYPE = 0x0102
RES_XML_END_ELEMENT_TYPE = 0x0103
RES_XML_CDATA_TYPE = 0x0104
RES_XML_RESOURCE_MAP_TYPE = 0x0180
RES_TABLE_PACKAGE_TYPE = 0x0200

UTF8_FLAG = 1 << 8

ANDROID_ATTR_IDS: dict[int, str] = {
    0x01010000: "theme",
    0x01010001: "label",
    0x01010002: "icon",
    0x01010003: "name",
    0x01010006: "permission",
    0x0101000E: "enabled",
    0x0101000F: "debuggable",
    0x01010010: "exported",
    0x01010011: "process",
    0x01010018: "authorities",
    0x0101001E: "launchMode",
    0x01010024: "value",
    0x01010025: "resource",
    0x01010027: "mimeType",
    0x01010028: "scheme",
    0x01010029: "host",
    0x0101002A: "port",
    0x0101002B: "path",
    0x0101002C: "pathPrefix",
    0x0101002D: "pathPattern",
    0x0101020C: "minSdkVersion",
    0x0101021B: "versionCode",
    0x0101021C: "versionName",
    0x01010270: "targetSdkVersion",
    0x01010272: "allowBackup",
    0x010103F0: "usesCleartextTraffic",
    0x010104EA: "extractNativeLibs",
    0x01010527: "networkSecurityConfig",
    0x01010574: "compileSdkVersion",
}

KNOWN_PACKER_APPS: dict[str, str] = {
    "com.stub.StubApp": "360 加固 (Qihoo 360 Jiagu)",
    "com.qihoo.util.StubApp": "360 加固 (Qihoo 360)",
    "s.h.e.l.l.S": "爱加密 (IJiami)",
    "com.secneo.apkwrapper": "梆梆加固 (Bangcle/SecNeo)",
    "com.SecShell.SecShell": "梆梆加固 (Bangcle SecShell)",
    "com.secshell.secData.ApplicationWrapper": "梆梆加固 (Bangcle)",
    "com.tencent.StubShell.TxAppEntry": "腾讯乐固 (Tencent Legu)",
    "com.baidu.protect.StubApplication": "百度加固 (Baidu Protect)",
    "com.netease.nis.wrapper.MyApplication": "网易易盾 (NetEase Yidun)",
    "com.kwai.allprotect.StubApp": "快手加固",
}


def _decode_utf8_len(buf: bytes, pos: int) -> tuple[int, int]:
    if pos >= len(buf):
        return 0, pos
    b = buf[pos]
    pos += 1
    if b & 0x80:
        if pos >= len(buf):
            return b & 0x7F, pos
        b2 = buf[pos]
        pos += 1
        return ((b & 0x7F) << 8) | b2, pos
    return b, pos


def _decode_utf16_len(buf: bytes, pos: int) -> tuple[int, int]:
    if pos + 2 > len(buf):
        return 0, pos
    (u1,) = struct.unpack_from("<H", buf, pos)
    pos += 2
    if u1 & 0x8000:
        if pos + 2 > len(buf):
            return u1 & 0x7FFF, pos
        (u2,) = struct.unpack_from("<H", buf, pos)
        pos += 2
        return ((u1 & 0x7FFF) << 16) | u2, pos
    return u1, pos


def parse_string_pool(buf: bytes, chunk_off: int) -> tuple[list[str], dict]:
    if chunk_off + 28 > len(buf):
        return [], {}
    ctype, hdr_sz, chunk_sz, str_cnt, style_cnt, flags, str_start, _style_start = (
        struct.unpack_from("<HHI5I", buf, chunk_off)
    )
    if ctype != RES_STRING_POOL_TYPE:
        return [], {}

    is_utf8 = bool(flags & UTF8_FLAG)
    offsets_base = chunk_off + hdr_sz
    pool_base = chunk_off + str_start
    strings: list[str] = []
    str_meta: list[tuple[int, int, int]] = []

    for i in range(str_cnt):
        idx_pos = offsets_base + i * 4
        if idx_pos + 4 > len(buf):
            strings.append("")
            continue
        (rel_off,) = struct.unpack_from("<I", buf, idx_pos)
        s_pos = pool_base + rel_off
        if s_pos >= len(buf) or s_pos >= chunk_off + chunk_sz:
            strings.append("")
            continue

        if is_utf8:
            _char_len, p = _decode_utf8_len(buf, s_pos)
            byte_len, p = _decode_utf8_len(buf, p)
            raw = buf[p : min(len(buf), p + byte_len)]
            s = raw.decode("utf-8", errors="replace")
            str_meta.append((p, byte_len, 1))
        else:
            char_len, p = _decode_utf16_len(buf, s_pos)
            byte_len = char_len * 2
            raw = buf[p : min(len(buf), p + byte_len)]
            s = raw.decode("utf-16le", errors="replace")
            # Detect byte-swapped UTF-16 strings (e.g. obfuscated resources.arsc where ASCII high byte is non-zero)
            if s and sum(1 for ch in s if 0x2000 <= ord(ch) <= 0x7F00 and (ord(ch) & 0xFF) == 0) > len(s) // 2:
                s = raw.decode("utf-16be", errors="replace")
            str_meta.append((p, byte_len, 2))
        strings.append(s)

    return strings, {
        "chunk_off": chunk_off,
        "chunk_sz": chunk_sz,
        "is_utf8": is_utf8,
        "pool_base": pool_base,
        "str_meta": str_meta,
    }


def format_typed_value(v_type: int, v_data: int, strings: list[str]) -> str:
    if v_type == 0x03:  # TYPE_STRING
        return strings[v_data] if 0 <= v_data < len(strings) else f"@string/{v_data}"
    if v_type == 0x10:  # TYPE_INT_DEC
        if v_data >= 0x80000000:
            return str(v_data - 0x100000000)
        return str(v_data)
    if v_type == 0x11:  # TYPE_INT_HEX
        return f"0x{v_data:x}"
    if v_type == 0x12:  # TYPE_INT_BOOLEAN
        return "true" if v_data != 0 else "false"
    if v_type == 0x01:  # TYPE_REFERENCE
        return f"@0x{v_data:08x}"
    if v_type == 0x02:  # TYPE_ATTRIBUTE
        return f"?0x{v_data:08x}"
    if 0x1C <= v_type <= 0x1F:  # TYPE_INT_COLOR_*
        return f"#{v_data:08x}"
    return f"0x{v_data:x}"


class AxmlDocument:
    def __init__(self, raw: bytes) -> None:
        self.raw = raw
        self.strings: list[str] = []
        self.pool_info: dict = {}
        self.res_ids: list[int] = []
        self.elements: list[dict] = []
        self.xml_lines: list[str] = ['<?xml version="1.0" encoding="utf-8"?>']
        self.attr_patches: list[dict] = []
        self._parse()

    def _get_str(self, idx: int) -> str:
        if 0 <= idx < len(self.strings):
            return self.strings[idx]
        return ""

    def _attr_name(self, name_idx: int) -> str:
        name = self._get_str(name_idx)
        if name:
            return name
        if 0 <= name_idx < len(self.res_ids):
            rid = self.res_ids[name_idx]
            return ANDROID_ATTR_IDS.get(rid, f"attr_0x{rid:08x}")
        return f"attr_{name_idx}"

    def _parse(self) -> None:
        buf = self.raw
        if len(buf) < 8:
            raise ValueError("AXML buffer too short")
        ctype, hdr_sz, total_sz = struct.unpack_from("<HHI", buf, 0)
        if ctype != RES_XML_TYPE:
            raise ValueError(f"Not a valid binary AXML (magic=0x{ctype:04x}, expected 0x0003)")

        pos = hdr_sz
        ns_uri_to_prefix: dict[str, str] = {
            "http://schemas.android.com/apk/res/android": "android"
        }
        pending_ns: list[tuple[str, str]] = []
        stack: list[dict] = []

        while pos + 8 <= len(buf) and pos < total_sz:
            ch_type, ch_hdr_sz, ch_sz = struct.unpack_from("<HHI", buf, pos)
            if ch_sz < 8:
                break

            if ch_type == RES_STRING_POOL_TYPE:
                self.strings, self.pool_info = parse_string_pool(buf, pos)

            elif ch_type == RES_XML_RESOURCE_MAP_TYPE:
                cnt = (ch_sz - ch_hdr_sz) // 4
                self.res_ids = list(struct.unpack_from(f"<{cnt}I", buf, pos + ch_hdr_sz))

            elif ch_type == RES_XML_START_NAMESPACE_TYPE and pos + 24 <= len(buf):
                prefix_idx, uri_idx = struct.unpack_from("<II", buf, pos + 16)
                pfx = self._get_str(prefix_idx) or "android"
                uri = self._get_str(uri_idx)
                if uri:
                    ns_uri_to_prefix[uri] = pfx
                    pending_ns.append((pfx, uri))

            elif ch_type == RES_XML_START_ELEMENT_TYPE and pos + 36 <= len(buf):
                _ns_idx, name_idx, attr_start, attr_size, attr_cnt = struct.unpack_from(
                    "<IIHHH", buf, pos + 16
                )
                tag = self._get_str(name_idx) or f"tag_{name_idx}"
                attrs: dict[str, str] = {}
                attr_base = pos + 16 + attr_start
                step = attr_size if attr_size >= 20 else 20

                for i in range(attr_cnt):
                    a_off = attr_base + i * step
                    if a_off + 20 > len(buf):
                        break
                    a_ns, a_name_idx, a_raw_val, a_size, _res0, a_type, a_data = (
                        struct.unpack_from("<IIIHBBI", buf, a_off)
                    )
                    a_name = self._attr_name(a_name_idx)
                    ns_uri = self._get_str(a_ns)
                    pfx = ns_uri_to_prefix.get(ns_uri, "")
                    full_name = f"{pfx}:{a_name}" if pfx and ":" not in a_name else a_name
                    val = (
                        self._get_str(a_raw_val)
                        if a_type == 0x03 and 0 <= a_raw_val < len(self.strings)
                        else format_typed_value(a_type, a_data, self.strings)
                    )
                    attrs[full_name] = val
                    rid = self.res_ids[a_name_idx] if 0 <= a_name_idx < len(self.res_ids) else 0
                    self.attr_patches.append(
                        {
                            "tag": tag,
                            "name": a_name,
                            "full_name": full_name,
                            "res_id": rid,
                            "attr_off": a_off,
                            "type": a_type,
                            "data": a_data,
                            "value": val,
                        }
                    )

                node = {
                    "tag": tag,
                    "attrs": attrs,
                    "children": [],
                    "parent": stack[-1]["tag"] if stack else "",
                }
                if stack:
                    stack[-1]["children"].append(node)
                self.elements.append(node)
                stack.append(node)

                indent = "  " * (len(stack) - 1)
                ns_decls = "".join(f' xmlns:{p}="{escape(u)}"' for p, u in pending_ns)
                pending_ns.clear()
                attr_str = "".join(f' {k}="{escape(str(v))}"' for k, v in attrs.items())
                self.xml_lines.append(f"{indent}<{tag}{ns_decls}{attr_str}>")

            elif ch_type == RES_XML_END_ELEMENT_TYPE:
                if stack:
                    node = stack.pop()
                    indent = "  " * len(stack)
                    self.xml_lines.append(f"{indent}</{node['tag']}>")

            pos += ch_sz


def parse_arsc_strings(raw: bytes, limit: int = 100, query: str = "") -> list[str]:
    if len(raw) < 12:
        return []
    ctype, hdr_sz, total_sz = struct.unpack_from("<HHI", raw, 0)
    if ctype != RES_TABLE_TYPE:
        return []
    out: list[str] = []
    pos = hdr_sz
    q = query.lower()
    while pos + 8 <= len(raw) and pos < total_sz:
        ch_type, ch_hdr_sz, ch_sz = struct.unpack_from("<HHI", raw, pos)
        if ch_sz < 8:
            break
        if ch_type == RES_STRING_POOL_TYPE:
            strs, _ = parse_string_pool(raw, pos)
            for s in strs:
                if s and (not q or q in s.lower()):
                    out.append(s)
                    if len(out) >= limit:
                        return out
        elif ch_type == RES_TABLE_PACKAGE_TYPE and pos + ch_hdr_sz <= len(raw):
            # Walk inner string pools (typeStrings & keyStrings) inside package chunk
            inner = pos + ch_hdr_sz
            pkg_end = min(len(raw), pos + ch_sz)
            while inner + 8 <= pkg_end:
                ic_type, _ic_hdr, ic_sz = struct.unpack_from("<HHI", raw, inner)
                if ic_sz < 8:
                    break
                if ic_type == RES_STRING_POOL_TYPE:
                    strs, _ = parse_string_pool(raw, inner)
                    for s in strs:
                        if s and (not q or q in s.lower()):
                            out.append(s)
                            if len(out) >= limit:
                                return out
                inner += ic_sz
        pos += ch_sz
    return out


def patch_axml_debuggable(raw: bytes, enable: bool) -> tuple[bytes, str]:
    doc = AxmlDocument(raw)
    buf = bytearray(raw)
    for ap in doc.attr_patches:
        if ap["tag"] == "application" and (
            ap["name"] == "debuggable" or ap["res_id"] == 0x0101000F
        ):
            off = ap["attr_off"]
            # Set raw_val = 0xFFFFFFFF, size=8, res0=0, type=0x12 (BOOLEAN), data=1 or 0
            struct.pack_into("<IHBBI", buf, off + 8, 0xFFFFFFFF, 8, 0, 0x12, 0xFFFFFFFF if enable else 0)
            return bytes(buf), f"Updated existing android:debuggable={enable} at 0x{off:x}"
    return bytes(buf), "No existing android:debuggable attribute in <application> (use apk_patch_repack or apktool to insert)"


def patch_axml_string_in_pool(raw: bytes, old_str: str, new_str: str) -> tuple[bytes, str]:
    doc = AxmlDocument(raw)
    if old_str not in doc.strings:
        raise ValueError(f"String '{old_str}' not found in AXML string pool")
    idx = doc.strings.index(old_str)
    meta = doc.pool_info["str_meta"][idx]
    p, byte_len, unit = meta
    buf = bytearray(raw)
    if unit == 1:
        enc = new_str.encode("utf-8")
        if len(enc) > byte_len:
            raise ValueError(
                f"In-place UTF-8 replacement '{new_str}' ({len(enc)}B) exceeds '{old_str}' ({byte_len}B)"
            )
        padded = enc + b"\x00" * (byte_len - len(enc))
        buf[p : p + byte_len] = padded
        if p >= 2 and buf[p - 1] == byte_len and buf[p - 2] == len(old_str):
            buf[p - 2] = len(new_str)
            buf[p - 1] = len(enc)
    else:
        enc = new_str.encode("utf-16le")
        if len(enc) > byte_len:
            raise ValueError(
                f"In-place UTF-16 replacement '{new_str}' ({len(enc)}B) exceeds '{old_str}' ({byte_len}B)"
            )
        padded = enc + b"\x00" * (byte_len - len(enc))
        buf[p : p + byte_len] = padded
        if p >= 2:
            struct.pack_into("<H", buf, p - 2, len(new_str))
    return bytes(buf), f"Patched string#{idx} '{old_str}' -> '{new_str}' at 0x{p:x}"


def print_summary(doc: AxmlDocument, apk_Entry_names: list[str] | None = None) -> None:
    manifest = next((e for e in doc.elements if e["tag"] == "manifest"), {"attrs": {}})
    app = next((e for e in doc.elements if e["tag"] == "application"), {"attrs": {}})
    m_attrs = manifest.get("attrs", {})
    a_attrs = app.get("attrs", {})

    pkg = m_attrs.get("package", "")
    v_code = m_attrs.get("android:versionCode", m_attrs.get("versionCode", ""))
    v_name = m_attrs.get("android:versionName", m_attrs.get("versionName", ""))
    uses_sdk = next((e for e in doc.elements if e["tag"] == "uses-sdk"), {"attrs": {}})["attrs"]
    min_sdk = uses_sdk.get("android:minSdkVersion", uses_sdk.get("minSdkVersion", ""))
    target_sdk = uses_sdk.get("android:targetSdkVersion", uses_sdk.get("targetSdkVersion", ""))

    app_cls = a_attrs.get("android:name", a_attrs.get("name", ""))
    debuggable = a_attrs.get("android:debuggable", a_attrs.get("debuggable", "false"))
    extract_native = a_attrs.get("android:extractNativeLibs", a_attrs.get("extractNativeLibs", "default"))

    print("=== AndroidManifest Summary ===")
    print(f"Package          : {pkg}")
    print(f"Version          : {v_name} (code={v_code})")
    print(f"SDK              : minSdk={min_sdk} targetSdk={target_sdk}")
    print(f"Application      : {app_cls or '(default android.app.Application)'}")
    print(f"Debuggable       : {debuggable} | extractNativeLibs={extract_native}")

    packer_hits: list[str] = []
    for k, desc in KNOWN_PACKER_APPS.items():
        if app_cls and (app_cls == k or app_cls.startswith(k)):
            packer_hits.append(f"{desc} [Application={app_cls}]")
    if apk_Entry_names:
        names_set = set(apk_Entry_names)
        for n in apk_Entry_names:
            bn = n.rsplit("/", 1)[-1]
            if bn.startswith("libjiagu"):
                packer_hits.append(f"360 加固 ({n})")
            elif bn.startswith(("libshella", "libshellx")) or bn in ("mix.dex", "mixz.dex"):
                packer_hits.append(f"腾讯乐固 ({n})")
            elif bn in ("libexec.so", "libexecmain.so", "ijiami.dat", "ijiami.ajm"):
                packer_hits.append(f"爱加密 ({n})")
            elif bn in ("libSecShell.so", "libDexHelper.so", "libsecexe.so"):
                packer_hits.append(f"梆梆加固 ({n})")
            elif bn.startswith("libbaiduprotect"):
                packer_hits.append(f"百度加固 ({n})")
            elif bn in ("libnesec.so", "libchaosvmp.so", "libddog.so"):
                packer_hits.append(f"商业加固壳 ({n})")
        dex_files = sorted(x for x in names_set if x.endswith(".dex") and "/" not in x)
        so_abis = sorted({x.split("/")[1] for x in names_set if x.startswith("lib/") and x.count("/") >= 2})
        print(f"DEX Files ({len(dex_files)})    : {', '.join(dex_files)}")
        print(f"Native ABIs      : {', '.join(so_abis) if so_abis else '(none)'}")

    print(f"Packer Detection : {', '.join(dict.fromkeys(packer_hits)) if packer_hits else 'None detected'}")

    perms = [
        e["attrs"].get("android:name", e["attrs"].get("name", ""))
        for e in doc.elements
        if e["tag"] == "uses-permission"
    ]
    if perms:
        print(f"\n[Permissions ({len(perms)})]")
        for p in perms[:30]:
            print(f"  - {p}")

    comp_tags = ("activity", "activity-alias", "service", "receiver", "provider")
    comps = [e for e in doc.elements if e["tag"] in comp_tags]
    print(f"\n[Components ({len(comps)} total)]")
    ad_or_update: list[str] = []
    for c in comps:
        ca = c["attrs"]
        cname = ca.get("android:name", ca.get("name", ""))
        exp = ca.get("android:exported", ca.get("exported", ""))
        actions = [
            ch["attrs"].get("android:name", ch["attrs"].get("name", ""))
            for inf in c["children"]
            if inf["tag"] == "intent-filter"
            for ch in inf["children"]
            if ch["tag"] == "action"
        ]
        is_launcher = "android.intent.action.MAIN" in actions
        tag_mark = " [MAIN/LAUNCHER]" if is_launcher else (" [EXPORTED]" if exp == "true" or (exp == "" and actions) else "")
        if is_launcher or exp == "true" or actions or c["tag"] == "provider":
            act_suffix = f" actions={actions}" if actions else ""
            print(f"  [{c['tag']}] {cname}{tag_mark}{act_suffix}")
        low = cname.lower()
        if any(w in low for w in ("ad", "gdt", "splash", "reward", "update", "upgrade", " stub")):
            ad_or_update.append(f"{c['tag']}: {cname}")

    if ad_or_update:
        print(f"\n[Ad / Splash / Update Candidate Components ({len(ad_or_update)})]")
        for item in ad_or_update[:25]:
            print(f"  * {item}")


def main() -> int:
    ap = argparse.ArgumentParser(description="Decode & patch Android binary XML (AXML) and resources.arsc.")
    ap.add_argument("target", type=Path, help="Path to .apk, binary AndroidManifest.xml, or resources.arsc")
    ap.add_argument("--xml", action="store_true", help="Print reconstructed XML of AndroidManifest.xml")
    ap.add_argument("--summary", action="store_true", help="Print structured security & component summary")
    ap.add_argument("--arsc-strings", default=None, metavar="QUERY", help="Search strings in resources.arsc (use '' for all)")
    ap.add_argument("--limit", type=int, default=80, help="Max strings to print for --arsc-strings")
    ap.add_argument("--set-debuggable", choices=["0", "1"], help="Patch android:debuggable in binary AXML")
    ap.add_argument("--replace-string", metavar="OLD=NEW", help="In-place replace a string in AXML string pool (len(NEW) <= len(OLD))")
    ap.add_argument("-o", "--output", type=Path, help="Output file path for binary AXML patch")
    args = ap.parse_args()

    raw_bytes = args.target.read_bytes()
    apk_entries: list[str] | None = None
    axml_bytes: bytes | None = None
    arsc_bytes: bytes | None = None

    if zipfile.is_zipfile(args.target):
        with zipfile.ZipFile(args.target, "r") as zf:
            apk_entries = zf.namelist()
            if "AndroidManifest.xml" in apk_entries:
                axml_bytes = zf.read("AndroidManifest.xml")
            if "resources.arsc" in apk_entries:
                arsc_bytes = zf.read("resources.arsc")
    else:
        ctype = struct.unpack_from("<H", raw_bytes, 0)[0] if len(raw_bytes) >= 2 else 0
        if ctype == RES_TABLE_TYPE:
            arsc_bytes = raw_bytes
        else:
            axml_bytes = raw_bytes

    if args.arsc_strings is not None:
        if not arsc_bytes:
            print("No resources.arsc found in target.", file=sys.stderr)
            return 1
        hits = parse_arsc_strings(arsc_bytes, limit=args.limit, query=args.arsc_strings)
        print(f"[resources.arsc strings matched: {len(hits)}]")
        for s in hits:
            print(f"  {s}")
        if not args.xml and not args.summary:
            return 0

    if not axml_bytes:
        print("No binary AndroidManifest.xml found in target.", file=sys.stderr)
        return 1

    if args.set_debuggable is not None or args.replace_string is not None:
        patched = axml_bytes
        if args.set_debuggable is not None:
            patched, msg = patch_axml_debuggable(patched, args.set_debuggable == "1")
            print(msg)
        if args.replace_string is not None:
            if "=" not in args.replace_string:
                print("--replace-string requires OLD=NEW", file=sys.stderr)
                return 1
            old_s, new_s = args.replace_string.split("=", 1)
            patched, msg = patch_axml_string_in_pool(patched, old_s, new_s)
            print(msg)
        if args.output:
            args.output.write_bytes(patched)
            print(f"Saved patched AXML ({len(patched)}B) -> {args.output}")
        return 0

    doc = AxmlDocument(axml_bytes)
    if args.xml:
        print("\n".join(doc.xml_lines))
    else:
        print_summary(doc, apk_entries)
    return 0


if __name__ == "__main__":
    sys.exit(main())
