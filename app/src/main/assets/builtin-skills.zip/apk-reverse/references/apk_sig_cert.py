#!/usr/bin/env python3
"""Pure-stdlib APK Signature (v1/v2/v3), X.509 Certificate, ASN.1 DER/PKCS#7, and Key Derivation Inspector.

Solves two major reverse-engineering bottlenecks without external dependencies:
1. Extracts the exact signing certificate(s) from APK v1 (META-INF/*.RSA/*.DSA/*.EC)
   and APK Signing Block v2 (0x7109871a) / v3 (0xf05368c0), then computes EVERY
   Android signature representation used by JNI / Java integrity & key-derivation checks:
   - Signature.toByteArray() (raw X.509 DER bytes)
   - MD5 / SHA1 / SHA256 of raw DER bytes
   - Signature.toCharsString() (Android's exact lowercase hex char expansion)
   - MD5 / SHA1 / SHA256 of toCharsString().encode('utf-8') (used by APICloud libsec.so, etc.)
   - Signature.hashCode() (Java Arrays.hashCode signed 32-bit int)
2. Parses arbitrary ASN.1 BER/DER & PKCS#7 SignedData blobs (e.g. assets/widget/res/config)
   and raw RSA modulus blobs (e.g. key.xml), extracting embedded eContent payloads,
   certificates, RSA public keys (n, e), and performing textbook RSA PKCS#1 v1.5 public
   decryption (m = pow(c, e, n)) for public-key encrypted config/key blobs.
"""

from __future__ import annotations

import argparse
import hashlib
import struct
import sys
import zipfile
from pathlib import Path

APK_SIG_BLOCK_MAGIC = b"APK Sig Block 42"
APK_V2_ID = 0x7109871A
APK_V3_ID = 0xF05368C0
APK_V31_ID = 0x1B93AD61

OID_MAP: dict[str, str] = {
    "1.2.840.113549.1.7.1": "pkcs7-data",
    "1.2.840.113549.1.7.2": "pkcs7-signedData",
    "1.2.840.113549.1.7.3": "pkcs7-envelopedData",
    "1.2.840.113549.1.1.1": "rsaEncryption",
    "1.2.840.113549.1.1.5": "sha1WithRSAEncryption",
    "1.2.840.113549.1.1.11": "sha256WithRSAEncryption",
    "2.5.4.3": "commonName",
    "2.5.4.6": "countryName",
    "2.5.4.10": "organizationName",
    "2.5.4.11": "organizationalUnitName",
}


def decode_oid(body: bytes) -> str:
    if not body:
        return ""
    parts = [str(body[0] // 40), str(body[0] % 40)]
    val = 0
    for b in body[1:]:
        val = (val << 7) | (b & 0x7F)
        if not (b & 0x80):
            parts.append(str(val))
            val = 0
    oid = ".".join(parts)
    return f"{oid} ({OID_MAP[oid]})" if oid in OID_MAP else oid


def parse_asn1(buf: bytes, start: int = 0, end: int | None = None, depth: int = 0) -> list[dict]:
    if end is None:
        end = len(buf)
    nodes: list[dict] = []
    pos = start
    while pos < end and depth <= 16:
        tag_off = pos
        tag = buf[pos]
        pos += 1
        if (tag & 0x1F) == 0x1F:
            while pos < end and (buf[pos] & 0x80):
                pos += 1
            pos += 1
        if pos >= end:
            break

        length_byte = buf[pos]
        pos += 1
        if length_byte == 0x80:
            # Indefinite length
            val_start = pos
            children = parse_asn1(buf, val_start, end, depth + 1)
            pos = children[-1]["end"] if children else end
            if pos + 2 <= end and buf[pos : pos + 2] == b"\x00\x00":
                pos += 2
            nodes.append(
                {
                    "off": tag_off,
                    "val_off": val_start,
                    "len": pos - val_start,
                    "end": pos,
                    "tag": tag,
                    "constructed": True,
                    "children": children,
                    "raw": buf[tag_off:pos],
                    "body": buf[val_start:pos],
                }
            )
            continue

        if length_byte & 0x80:
            num_bytes = length_byte & 0x7F
            if num_bytes == 0 or pos + num_bytes > end:
                break
            length = int.from_bytes(buf[pos : pos + num_bytes], "big")
            pos += num_bytes
        else:
            length = length_byte

        val_start = pos
        val_end = min(end, val_start + length)
        constructed = bool(tag & 0x20)
        body = buf[val_start:val_end]
        children: list[dict] = []
        if constructed and length > 0:
            children = parse_asn1(buf, val_start, val_end, depth + 1)

        nodes.append(
            {
                "off": tag_off,
                "val_off": val_start,
                "len": length,
                "end": val_end,
                "tag": tag,
                "constructed": constructed,
                "children": children,
                "raw": buf[tag_off:val_end],
                "body": body,
            }
        )
        pos = val_end
    return nodes


def walk_asn1(nodes: list[dict]):
    for n in nodes:
        yield n
        if n["children"]:
            yield from walk_asn1(n["children"])


def is_x509_cert_node(node: dict) -> bool:
    # Certificate ::= SEQUENCE { tbsCertificate SEQUENCE, signatureAlgorithm SEQUENCE, signatureValue BIT STRING }
    if node["tag"] != 0x30 or len(node["children"]) != 3:
        return False
    c0, c1, c2 = node["children"]
    return c0["tag"] == 0x30 and c1["tag"] == 0x30 and c2["tag"] == 0x03 and len(c0["children"]) >= 5


def extract_x509_certs_from_der(blob: bytes) -> list[bytes]:
    certs: list[bytes] = []
    nodes = parse_asn1(blob)
    for n in walk_asn1(nodes):
        if is_x509_cert_node(n):
            certs.append(n["raw"])
        elif (n["tag"] & 0xE0) == 0x80 and not n["constructed"] and len(n["body"]) > 128:
            # Sometimes IMPLICIT [0] wraps a SEQUENCE without constructed bit set
            sub = parse_asn1(n["body"])
            for sn in walk_asn1(sub):
                if is_x509_cert_node(sn):
                    certs.append(sn["raw"])
    return certs


def extract_rsa_pubkey_from_der(blob: bytes) -> list[tuple[int, int]]:
    keys: list[tuple[int, int]] = []
    nodes = parse_asn1(blob)
    for n in walk_asn1(nodes):
        if n["tag"] == 0x03 and len(n["body"]) > 32:
            # BIT STRING (skip leading unused-bits byte 0x00)
            inner = parse_asn1(n["body"][1:])
            if len(inner) == 1 and inner[0]["tag"] == 0x30 and len(inner[0]["children"]) == 2:
                c0, c1 = inner[0]["children"]
                if c0["tag"] == 0x02 and c1["tag"] == 0x02 and len(c0["body"]) >= 64:
                    mod = int.from_bytes(c0["body"], "big")
                    exp = int.from_bytes(c1["body"], "big")
                    keys.append((mod, exp))
    return keys


def android_to_chars_string(cert_der: bytes) -> str:
    """Exact port of android.content.pm.Signature.toCharsString()."""
    out = []
    for v in cert_der:
        d_high = (v >> 4) & 0xF
        d_low = v & 0xF
        out.append(chr(ord("a") + d_high - 10) if d_high >= 10 else chr(ord("0") + d_high))
        out.append(chr(ord("a") + d_low - 10) if d_low >= 10 else chr(ord("0") + d_low))
    return "".join(out)


def java_arrays_hashcode(data: bytes) -> int:
    """Exact port of java.util.Arrays.hashCode(byte[]) used by Signature.hashCode()."""
    h = 1
    for b in data:
        sb = b - 256 if b >= 128 else b
        h = (31 * h + sb) & 0xFFFFFFFF
    return h - 0x100000000 if h >= 0x80000000 else h


def extract_v2_v3_certs(apk_bytes: bytes) -> list[tuple[str, bytes]]:
    results: list[tuple[str, bytes]] = []
    eocd_idx = apk_bytes.rfind(b"PK\x05\x06")
    if eocd_idx < 0 or eocd_idx + 20 > len(apk_bytes):
        return results
    (cd_offset,) = struct.unpack_from("<I", apk_bytes, eocd_idx + 16)
    if cd_offset < 32 or apk_bytes[cd_offset - 16 : cd_offset] != APK_SIG_BLOCK_MAGIC:
        return results
    (block_sz_footer,) = struct.unpack_from("<Q", apk_bytes, cd_offset - 24)
    block_start = cd_offset - 8 - block_sz_footer
    if block_start < 0:
        return results
    pos = block_start + 8
    pairs_end = cd_offset - 24
    while pos + 12 <= pairs_end:
        (pair_len,) = struct.unpack_from("<Q", apk_bytes, pos)
        if pair_len < 4 or pos + 8 + pair_len > pairs_end:
            break
        (pair_id,) = struct.unpack_from("<I", apk_bytes, pos + 8)
        val = apk_bytes[pos + 12 : pos + 8 + pair_len]
        if pair_id in (APK_V2_ID, APK_V3_ID, APK_V31_ID):
            scheme = "v2" if pair_id == APK_V2_ID else ("v3" if pair_id == APK_V3_ID else "v3.1")
            # Walk length-prefixed signers -> signedData -> certificates
            if len(val) >= 4:
                (signers_len,) = struct.unpack_from("<I", val, 0)
                s_pos = 4
                while s_pos + 4 <= 4 + signers_len and s_pos + 4 <= len(val):
                    (signer_len,) = struct.unpack_from("<I", val, s_pos)
                    signer = val[s_pos + 4 : s_pos + 4 + signer_len]
                    if len(signer) >= 4:
                        (sd_len,) = struct.unpack_from("<I", signer, 0)
                        sd = signer[4 : 4 + sd_len]
                        # In v2/v3 signedData: digests (len-prefixed), then certificates (len-prefixed)
                        if len(sd) >= 8:
                            (dig_len,) = struct.unpack_from("<I", sd, 0)
                            c_pos = 4 + dig_len
                            if c_pos + 4 <= len(sd):
                                (certs_len,) = struct.unpack_from("<I", sd, c_pos)
                                certs_buf = sd[c_pos + 4 : c_pos + 4 + certs_len]
                                cp = 0
                                while cp + 4 <= len(certs_buf):
                                    (clen,) = struct.unpack_from("<I", certs_buf, cp)
                                    cert_der = certs_buf[cp + 4 : cp + 4 + clen]
                                    if cert_der:
                                        results.append((f"APK-Sig-Block-{scheme}", cert_der))
                                    cp += 4 + clen
                    s_pos += 4 + signer_len
        pos += 8 + pair_len
    return results


def print_cert_derivations(source: str, cert_der: bytes, idx: int = 0) -> None:
    chars_str = android_to_chars_string(cert_der)
    chars_bytes = chars_str.encode("ascii")
    java_hc = java_arrays_hashcode(cert_der)

    print(f"=== Certificate #{idx} [{source}] ({len(cert_der)} bytes) ===")
    print(f"  Signature.hashCode() (Java int)   : {java_hc} (0x{java_hc & 0xFFFFFFFF:08x})")
    print(f"  [Raw DER: Signature.toByteArray()]")
    print(f"    MD5(toByteArray)                : {hashlib.md5(cert_der).hexdigest()}")
    print(f"    SHA1(toByteArray)               : {hashlib.sha1(cert_der).hexdigest()}")
    print(f"    SHA256(toByteArray)             : {hashlib.sha256(cert_der).hexdigest()}")
    print(f"  [Hex String: Signature.toCharsString() -> len={len(chars_str)}]")
    print(f"    toCharsString prefix (64 chars) : {chars_str[:64]}...")
    print(f"    MD5(toCharsString)              : {hashlib.md5(chars_bytes).hexdigest()}")
    print(f"    SHA1(toCharsString)             : {hashlib.sha1(chars_bytes).hexdigest()}")
    print(f"    SHA256(toCharsString)           : {hashlib.sha256(chars_bytes).hexdigest()}")
    for mod, exp in extract_rsa_pubkey_from_der(cert_der):
        print(f"  [RSA Public Key] bits={mod.bit_length()} e=0x{exp:x} n_prefix=0x{ hex(mod)[2:34] }...")


def inspect_pkcs7_or_asn1(data: bytes) -> None:
    nodes = parse_asn1(data)
    print(f"=== ASN.1 / PKCS#7 Structure ({len(data)} bytes) ===")
    for n in walk_asn1(nodes):
        t = n["tag"]
        body = n["body"]
        if t == 0x06:
            print(f"  @0x{n['off']:04x} OID len={n['len']}: {decode_oid(body)}")
        elif t == 0x04 and n["len"] > 0:
            preview = body[:32].hex()
            ascii_p = "".join(chr(b) if 32 <= b < 127 else "." for b in body[:32])
            print(f"  @0x{n['off']:04x} OCTET STRING len={n['len']} val_off=0x{n['val_off']:04x}: hex={preview} ascii='{ascii_p}'")
        elif (t & 0xE0) == 0x80 or (t & 0xE0) == 0xA0:
            ctx_num = t & 0x1F
            print(f"  @0x{n['off']:04x} CONTEXT [{ctx_num}] tag=0x{t:02x} len={n['len']} val_off=0x{n['val_off']:04x} hex={body[:24].hex()}...")
    certs = extract_x509_certs_from_der(data)
    for i, c in enumerate(certs):
        print_cert_derivations("Embedded-X509", c, i)


def rsa_public_unpad(cipher_bytes: bytes, mod_n: int, exp_e: int = 0x10001) -> bytes | None:
    k = (mod_n.bit_length() + 7) // 8
    c = int.from_bytes(cipher_bytes, "big")
    m = pow(c, exp_e, mod_n)
    em = m.to_bytes(k, "big")
    if len(em) >= 11 and em[0] == 0x00 and em[1] in (0x01, 0x02):
        sep = em.find(b"\x00", 2)
        if sep > 2:
            return em[sep + 1 :]
    return em


def main() -> int:
    ap = argparse.ArgumentParser(description="Extract APK v1/v2/v3 signatures, hash derivations, and ASN.1/PKCS#7 blobs.")
    ap.add_argument("target", type=Path, help="Path to .apk, META-INF/*.RSA, or ASN.1/PKCS#7 file")
    ap.add_argument("--asn1", action="store_true", help="Force detailed ASN.1 / PKCS#7 node dump")
    ap.add_argument("--dump-cert", type=Path, help="Write first extracted X.509 DER certificate to file")
    ap.add_argument("--rsa-mod-file", type=Path, help="File containing raw 256-byte RSA modulus or X.509 cert for textbook RSA")
    ap.add_argument("--rsa-cipher-hex", default="", help="Hex ciphertext to textbook-RSA public-decrypt (m = c^e mod n)")
    args = ap.parse_args()

    raw = args.target.read_bytes()

    if args.rsa_mod_file and args.rsa_cipher_hex:
        m_raw = args.rsa_mod_file.read_bytes()
        pub_keys = extract_rsa_pubkey_from_der(m_raw)
        if pub_keys:
            n, e = pub_keys[0]
        else:
            n = int.from_bytes(m_raw[:256], "big")
            e = 0x10001
        c_bytes = bytes.fromhex(args.rsa_cipher_hex.strip())
        out = rsa_public_unpad(c_bytes, n, e)
        print(f"RSA public operation result ({len(out or b'')}B): {(out or b'').hex()}")
        if out:
            print(f"ASCII preview: {out.decode('utf-8', errors='replace')}")
        return 0

    if zipfile.is_zipfile(args.target) and not args.asn1:
        certs: list[tuple[str, bytes]] = []
        with zipfile.ZipFile(args.target, "r") as zf:
            for name in zf.namelist():
                up = name.upper()
                if up.startswith("META-INF/") and up.endswith((".RSA", ".DSA", ".EC")):
                    blob = zf.read(name)
                    for c in extract_x509_certs_from_der(blob):
                        certs.append((name, c))
        certs.extend(extract_v2_v3_certs(raw))
        if not certs:
            print("No v1/v2/v3 certificates found in APK.")
            return 1
        seen: set[bytes] = set()
        idx = 0
        for src, c in certs:
            if c in seen:
                continue
            seen.add(c)
            if idx == 0 and args.dump_cert:
                args.dump_cert.write_bytes(c)
                print(f"Saved raw certificate DER -> {args.dump_cert}")
            print_cert_derivations(src, c, idx)
            idx += 1
        return 0

    inspect_pkcs7_or_asn1(raw)
    return 0


if __name__ == "__main__":
    sys.exit(main())
