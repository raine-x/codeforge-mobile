---
name: apk-reverse
display_name: APK 逆向分析与修改重打包
description: 安卓 APK 深度静态逆向与修改重打包工作流：二进制 AXML/ARSC 解析、v1/v2/v3 签名派生、多 DEX 字节码反汇编、交叉引用与对齐重签
triggers: reverse_analysis,逆向,apk,dex,smali,jadx,加固,脱壳,AndroidManifest,包名,重打包,签名,去广告,去更新,补丁
enabled: true
---

# APK 逆向分析与修改重打包

> 仅限本地拥有或明确授权的样本；未开启「允许修改与重打包」时默认执行只读分析，开启后修改前须保留原始包或校验 SHA256。

## 0. 防空转铁律（必读，节省 70% 轮次）
1. **严禁手写二进制 `AndroidManifest.xml`（AXML）、`resources.arsc`、ASN.1 / PKCS#7 解析器** —— 直接调用本技能内置脚本，1 条命令出结果。
2. **严禁先全量 `unzip` 整个大 APK 再逐个找 DEX** —— 内置脚本全部支持直接传入 `.apk` 文件路径。
3. **临时 Python 脚本严禁命名为 `dis.py`、`code.py`、`token.py`、`types.py`、`string.py`、` inspect.py`**（会遮蔽 Python 标准库导致 `capstone`/`unicorn` 崩溃），一律以 `cf_work_*.py` 命名。

## 1. 一步完成包清单、加固壳、组件与资源字符串侦察
无需 `apktool`，直接用内置 `axml_arsc_parser.py` 解析二进制 `AndroidManifest.xml` 与 `resources.arsc`（自动处理字节序颠倒的混淆 UTF-16 资源）：
```bash
# 输出包名、版本、Application 入口、加固壳识别、权限、导出组件与可疑广告/更新组件
python3 .codeforge/skills/apk-reverse/references/axml_arsc_parser.py app.apk --summary

# 还原完整明文 AndroidManifest.xml
python3 .codeforge/skills/apk-reverse/references/axml_arsc_parser.py app.apk --xml

# 检索 resources.arsc 字符串池（自动兼容 UTF-8 / UTF-16LE / 颠倒字节序 UTF-16BE）
python3 .codeforge/skills/apk-reverse/references/axml_arsc_parser.py app.apk --arsc-strings "" --limit 80
```

## 2. 一步提取 APK 签名证书（v1/v2/v3）、签名派生 Key 与 PKCS#7 容器
遇到 `getPackageInfo → signatures[0] → toByteArray() / toCharsString() → MD5/RC4` 签名校验或 `assets/**/config`（PKCS#7）、`key.xml`（RSA 公钥）时，**严禁手写 DER 解析或猜格式**，直接运行：
```bash
# 自动提取 v1/v2/v3 证书并一次性输出 raw DER、toCharsString()、Java hashCode 及 6 种 MD5/SHA1/SHA256
python3 .codeforge/skills/apk-reverse/references/apk_sig_cert.py app.apk

# 解析任意 ASN.1 / PKCS#7 SignedData 文件（自动提取 eContent 密文、OID 与内嵌证书）
python3 .codeforge/skills/apk-reverse/references/apk_sig_cert.py assets/widget/res/config --asn1

# 对公钥加密数据执行教科书 RSA 公钥解包 (m = c^e mod n，自动去 PKCS#1 v1.5 填充)
python3 .codeforge/skills/apk-reverse/references/apk_sig_cert.py key.xml --rsa-mod-file key.xml --rsa-cipher-hex 8c81f459...
```

## 3. 多 DEX 索引、尾部隐藏载荷检测、Dalvik 反汇编与交叉引用（Xref）
`dex_inspector.py` 支持直接传入 `.apk`（自动遍历全部 `classes*.dex`），并自动检测 `classes.dex` 尾部追加的加固壳加密 DEX 载荷：
```bash
# 查看所有 DEX 概览、检测 classes.dex 尾部追加载荷（可加 --extract-tail tail.bin 切出）并列出所有 JNI native 方法
python3 .codeforge/skills/apk-reverse/references/dex_inspector.py app.apk --native

# 搜索关键字符串并反查是哪个类的哪个方法引用了它（Xref）
python3 .codeforge/skills/apk-reverse/references/dex_inspector.py app.apk --strings vip --xref vip

# 按类名或方法名反汇编 Dalvik 字节码（直接给出文件绝对偏移 file_off 与符号解析）
python3 .codeforge/skills/apk-reverse/references/dex_inspector.py app.apk --disasm MainActivity
```
若已安装「APK 逆向工具链」环境包，也可按单类调用 `jadx` 或 `baksmali`：
```bash
jadx --single-class com.example.MainActivity -d /tmp/jadx_out app.apk
baksmali d classes.dex -o /tmp/smali_out
```

## 4. 修改、去广告/去更新、改包名与对齐重签名（需开启「允许修改与重打包」）
优先使用**局部无损修改**（避免 `apktool b` 因混淆资源报错）：
```bash
# 1) 直接把指定 Dalvik 方法改为返回 true(1) / false(0) / void，自动重算 DEX SHA-1 与 Adler32 并重打包对齐
python3 .codeforge/skills/apk-reverse/references/apk_patch_repack.py patch-return app.apk --method "UpdateManager->hasUpdate" --ret 0 -o app_patched.apk --sign

# 2) 按文件偏移直接打二进制补丁（若是 DEX 自动重算头部 SHA-1 与 Adler32）
python3 .codeforge/skills/apk-reverse/references/apk_patch_repack.py patch-hex classes.dex --offset 0x1234 --hex 12100f00

# 3) 二进制 AXML 原地开启 debuggable 或等长替换包名/组件名字符串（免 apktool 重编资源）
python3 .codeforge/skills/apk-reverse/references/axml_arsc_parser.py app.apk --set-debuggable 1 --replace-string com.old.app=com.new.app -o AndroidManifest_patched.xml

# 4) 无损替换 APK 内单个文件或移除广告插件条目，自动强制 resources.arsc 4B 未压缩对齐 + .so 4KB/16KB 对齐并签名
python3 .codeforge/skills/apk-reverse/references/apk_patch_repack.py repack app.apk -o app_signed.apk --replace AndroidManifest.xml=AndroidManifest_patched.xml --remove "assets/gdt_plugin/*" --sign
```
