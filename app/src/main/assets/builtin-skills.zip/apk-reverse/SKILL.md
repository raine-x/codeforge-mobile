---
name: apk-reverse
display_name: APK 逆向工程与加固脱壳分析
description: 安卓 APK 静态与动态逆向工作流：清单签名取证、多 DEX 类方法索引、常见加固壳特征识别、JNI 桥定位与 Frida 只读探测思路
triggers: apk,dex,smali,jadx,加固,脱壳,AndroidManifest
enabled: true
---

# APK 逆向工程与加固脱壳分析

> 仅限本地拥有或明确授权的样本；默认以只读方式分析结构与证据，不得修改原包或用于未授权目标。

## 1. 取证与包结构初探
1. 记录样本哈希与基本信息：`sha256sum app.apk`、`file app.apk`。
2. 列出 ZIP 归档内容：`unzip -l app.apk`（关注 `AndroidManifest.xml`、`classes*.dex`、`lib/<abi>/*.so`、`assets/`、`META-INF/*`）。
3. 需细查包内二进制时，解压至独立临时目录：`unzip -q app.apk -d /tmp/apk_work`。

## 2. 加固壳厂商特征快速识别
排查 `AndroidManifest.xml` 入口 `Application`、`lib/` 原生库名及 `assets/` 文件：
- **360 加固**：`libjiagu.so`、`libjiagu_a64.so`、`.appkey`、`assets/libjiagu*.so`
- **腾讯乐固**：`libshella-*.so`、`libshellx-*.so`、`mix.dex`、`mixz.dex`、`0OO00l111l1l`
- **爱加密**：`libexec.so`、`libexecmain.so`、`ijiami.dat`、`ijiami.ajm`
- **梆梆加密**：`libSecShell.so`、`libDexHelper.so`、`assets/dex.dat`、`libsecexe.so`
- **百度加固**：`libbaiduprotect.so`、`baiduprotect1.jar`
- **娜迦 / 瑞星 / 顶象 / 网易易盾**：`libchaosvmp.so`、`libddog.so`、`libx3g.so`、`libnesec.so`

## 3. DEX 结构与类方法索引（零第三方依赖）
对提取出的 `classes*.dex` 使用内置辅助脚本查看头信息、类列表与字符串引用：
```bash
python3 .codeforge/skills/apk-reverse/references/dex_inspector.py /tmp/apk_work/classes.dex --filter MainActivity
python3 .codeforge/skills/apk-reverse/references/dex_inspector.py /tmp/apk_work/classes.dex --strings encrypt --limit 40
```
若已安装 `jadx` / `apktool`，可再做资源与 Java 伪代码还原（结论须回查字节码/SMALI，不直接把反编译伪代码当成唯一事实）。

## 4. 分析报告规范
- 列出样本文件名、SHA256、包内 DEX 数量、支持的 ABI 与原生库列表；
- 明确标注是否命中加固壳特征及对应文件依据；
- 对关键验证逻辑给出类名、方法签名、字符串常量与对应的 native/JNI 关联。
