# CodeForge · 源码压缩包

**打包时间**：2026-11-02 08:30 CST
**基线提交**：`75681c1`（`合并远端更新`）
**内容**：**工作区当前快照**，包含全部未提交改动

---

## 包里有什么

```
code-forge-m/              完整源码树（305 个文件，git 跟踪集 + 新增字体目录）
changes-vs-HEAD.patch      相对 75681c1 的全部未提交改动（可审阅）
MANIFEST.md                本文件
```

### 源码树包含

| 部分 | 位置 | 说明 |
|---|---|---|
| Android 壳 | `app/src/main/java/app/codeforge/` | Kotlin + Compose，49 个文件 / 25,387 行，**无 XML 布局** |
| Go 内核产物 | `app/src/main/jniLibs/arm64-v8a/libcodeforge.so` | 17.4 MB |
| Rust 渲染引擎 | `app/src/main/jniLibs/arm64-v8a/libopenrender.so` | 8.3 MB，**含内嵌 CJK 字体** |
| 渲染引擎桥接 | `tools/openrender/app_jni.rs` | JNI 桥 + 字体安装逻辑 |
| CJK 字体子集 | `tools/openrender/fonts/` | Noto Sans SC 子集，3.1 MB，OFL-1.1 + LICENSE |
| 引擎构建脚本 | `tools/openrender/build-android.ps1` | Windows 版交叉编译脚本 |
| 兼容环境资产 | `app/src/main/assets/` | proot/Alpine/离线语音模型 |
| 三份记录 | `AGENTS.md` / `工作进程.md` / `改动历史.md` | 准则与坑位 / 进度 / 变更流水 |
| 方案文档 | `docs/` | 架构方案与 Web 端 UI 对齐清单 |

---

## 刻意排除的内容

| 排除项 | 原因 |
|---|---|
| `.git/` | 99 MB 历史；且内含**私有仓库地址**，不适合公开 |
| `local.properties` | 含构建机 SDK 绝对路径，且已在 `.gitignore` 中 |
| `.gradle/`、`.kotlin/`、`build/` | 构建缓存与产物 |
| 令牌 / 密钥 | 全包扫描确认**零命中**（私有仓库地址 / 访问令牌 / 构建机路径 均无） |

---

## 当前状态

**渲染引擎**：增量 Markdown IR + RaTeX 公式排版。含中文的块级公式
（`aligned` / `cases` / `bmatrix`）已修复 —— 做法是把 Noto Sans SC 子集内嵌进 `.so`
并通过 `RATEX_UNICODE_FONT` 指向，**未引入任何新依赖**。

**表格列宽**：改为按实际渲染宽度分配（不再按字符数），表头不再被挤断行。

**验证状态**：

- ✅ 引擎 IR 级实证（自编译探针 + 真实输入，7/7 用例出图）
- ✅ 产物级（`.so` 为 ARM64 ELF / stripped / LOAD 段 16KB 页对齐 / 符号齐全 / 字体字节完整嵌入）
- ✅ 单元测试 11/11 通过
- ✅ APK v2 签名通过
- ⚠️ **真机运行时未验证** —— 无真机环境，相关条目一律标注「运行时未验证」

---

## 从源码构建

需要 **JDK 17** + **Android SDK**（compileSdk 36 / build-tools 36.0.0），
ABI 仅 `arm64-v8a`。

```bash
cd code-forge-m
# 按需写 local.properties：
#   sdk.dir=/your/AndroidSDK
./gradlew assembleDebug
# → app/build/outputs/apk/debug/app-debug.apk
```

**版本是钉死的**，不要随手升 —— 升级要整条链一起动。
理由见 `AGENTS.md` 的「版本锁定」一节。

### 重编原生库

**Go 内核**（源码在 `source/CodeForge-GO/`，本包内为空 —— 它是独立仓库）：

```bash
CGO_ENABLED=0 GOOS=android GOARCH=arm64 \
  go build -trimpath -ldflags "-s -w" -o app/src/main/jniLibs/arm64-v8a/libcodeforge.so ./cmd/agent
```

**Rust 渲染引擎**：

```bash
# 需 NDK r30 + Rust（target aarch64-linux-android）
# 字体必须与 app_jni.rs 同目录（include_bytes! 要求）
cp tools/openrender/fonts/NotoSansSC-Subset.ttf <crate>/src/
cd <OpenRender 源码目录>
cargo build --release --target aarch64-linux-android \
  -p openrender-core --features jni,ratex --lib
```

> 上游：`raine-x/OpenRender` @ `6f11851722772b1a18388364b20a613a0aa2a020`
> crates.io 需配 **sparse index**（git index 会卡死）。
> 完整 JNI 桥补丁见 `tools/openrender/app_jni.rs`。

---

## 许可

源码版权归 CodeForge 项目所有。
`tools/openrender/fonts/NotoSansSC-Subset.ttf` 来自 Noto Sans CJK，
按 **SIL Open Font License 1.1** 发布，许可证全文见 `tools/openrender/fonts/LICENSE.txt`。
